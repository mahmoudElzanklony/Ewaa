<?php

return [
  'image_error'=>'please upload valid extension for image like jpeg or png or jpg or gif',
  'unauthenticated'=>'phone number or password is not correct',
    'unauthenticated_serial'=>'phone number of serial code is not correct',


];
