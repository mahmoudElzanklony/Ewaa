<?php

return [
  'image_error'=>'من فضلك ارفع امتداد صحيح يكون png او jpeg او jpg او gif',
  'unauthenticated'=>'رقم الهاتف او كلمه المرور غير صحيحه',
    'unauthenticated_serial'=>'رقم الهاتف او رمز الكود غير صحيح',
    'error_upload_image'=>'لابد ان يكون نوع الملف صورة',
    'unauthorized'=>'غير مسموح لك بتنفيذ هذا الامر',
    'payment_before'=>'تم دفع هذا الاعلان من قبل',
    'payment_unauthorized_user'=>'انت لست صاحب هذا الاعلان',
    'not_enough_points'=>'ليس لديك رصيد كافي من النقاط',
    'not_found_user'=>'لا يوجد مستخدم بهذه البيانات',
    'missing_info'=>'هناك بيانات ناقصة في اتمام العملية',
];
