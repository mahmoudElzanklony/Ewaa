<?php

return [
  'image_error'=>'من فضلك ارفع امتداد صحيح يكون png او jpeg او jpg او gif',
  'unauthenticated'=>'رقم الهاتف او كلمه المرور غير صحيحه',
    'unauthenticated_serial'=>'رقم الهاتف او رمز الكود غير صحيح',
    'error_upload_image'=>'لابد ان يكون نوع الملف صورة',
    'unauthorized'=>'غير مسموح لك بتنفيذ هذا الامر',
];
