<?php

return [
  'registered_user'=>'تمت عملية التسجيل بنجاح',
  'err_invalid_type'=>'خطأ في نوع المستخدم',
  'unauthenticated_err_form'=>'خطأ في البريد الألكتروني او كلمة المرور',
  'updated_successfully'=>'تمت عملية التعديل بنجاح',
  'deleted_successfully'=>'تمت عملية المسح بنجاح',
  'saved_successfully'=>'تم حفظ العملية بنجاح',
  'removed_from_fav_successfully'=>'تمت الازاله من المفضلة بنجاح',
  'added_to_fav_successfully'=>'تمت الاضافة الي المفضلة بنجاح',
];
