<!DOCTYPE html>
<html>
<head>
    <title>mall 14 reset password</title>
</head>
<body>
<h1>{{ $details['title'] }}</h1>
<p>{{ $details['body'] }}</p>
<a href="mall14.com/newreset/{{ $details['key']  }}">press here to reset password</a>

<p>Thank you</p>
</body>
</html>
