<?php


namespace App\Keywords\Profile;


class ProfileFavouritesKeywords
{
    public static function get_keywords(){
        return [

        ];
    }
}
