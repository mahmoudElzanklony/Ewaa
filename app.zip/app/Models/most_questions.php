<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class most_questions extends Model
{
    use HasFactory;

    public $fillable = ['question','answer'];
}
