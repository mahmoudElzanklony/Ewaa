<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SiteInfo extends Model
{
    use HasFactory;

    protected $fillable = ['name','ar_content','en_content'];

    public static function selection(){
        return self::query()->select('id','name',app()->getLocale().'_content as content');
    }
}
