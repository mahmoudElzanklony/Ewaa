<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class users_promo_codes extends Model
{
    use HasFactory;

    protected $fillable = ['user_id','promo_code_id','pieces'];

    public function promo(){
        return $this->belongsTo(promo_codes::class,'promo_code_id');
    }
}
