<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class cities extends Model
{
    use HasFactory;

    protected $fillable = ['governate_id','ar_name','en_name'];

    public static function selectoin(){
        return self::query()->select('id','governate_id',app()->getLocale().'_name as name');
    }
}
