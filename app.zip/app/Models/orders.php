<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class orders extends Model
{
    use HasFactory;

    protected $fillable = ['user_id','product_id','client_name','address','center_id','pieces',
        'price','order_type','info','payment_type','order_status','seller_profit_status'];



    public  function  user(){
        return $this->belongsTo(User::class);
    }

    public function product(){
        return $this->belongsTo(products::class);
    }
    public function rate(){
        return $this->hasMany(rates::class,'order_id');
    }

    public function client_answer(){
        return $this->hasMany(orders_clinets_choices::class,'order_id');
    }

    public function orders_promo_code(){
        return $this->hasOne(orders_promo_code::class,'order_id');
    }

    public function order_piece_data(){
        return $this->hasMany(order_piece_data::class,'order_id');
    }


}
