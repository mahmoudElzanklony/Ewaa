<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class packages extends Model
{
    use HasFactory;

    protected $fillable = ['ar_name','ar_info','en_name','en_info','no_products','no_orders'];

    public static function selection(){
        return self::query()->select('id',
            app()->getLocale().'_name as name',app()->getLocale().'_info as info',
            'no_products','no_orders');
    }
}
