<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class marketer_info extends Model
{
    use HasFactory;


    protected $table = 'marketer_info';

    protected $fillable = ['user_id','page_link'];
}
