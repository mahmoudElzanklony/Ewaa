<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class orders_clinets_choices extends Model
{
    use HasFactory;

    protected $fillable = ['user_id','order_id','client_answer_id'];

    public function product_answer(){
        return $this->belongsTo(products_answers::class,'client_answer_id');
    }
}
