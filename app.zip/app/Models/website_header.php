<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class website_header extends Model
{

    protected $table = 'website_header';

    protected $fillable = ['ar_content','en_content','image','url','type'];

    public static function selection(){
        return self::query()->select('id','image',app()->getLocale().'_content as content','url','type');
    }

    use HasFactory;
}
