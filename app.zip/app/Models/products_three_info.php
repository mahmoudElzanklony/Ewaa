<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class products_three_info extends Model
{
    use HasFactory;
    protected $fillable = ['product_id','ar_info',
        'en_info','price','in_stock','discount','start_discount_date_three','end_discount_date_three'];


    public static function selection(){
        return self::query()->select('id','product_id',
            app()->getLocale().'_info as info',
            'price','in_stock','discount','start_discount_date_three','end_discount_date_three');
    }
    public function product(){
        return $this->belongsTo(products::class,'product_id');
    }


}
