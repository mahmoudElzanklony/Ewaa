<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class categories extends Model
{
    use HasFactory;
    protected  $table = 'categories';
    protected $fillable = ['ar_name','en_name','ar_info','en_info','image','cover','parent_id',
        'cat_order','status','profit_percentage'];

    public function children()
    {
        return $this->hasMany(categories::class,'parent_id');
    }


    public static function selection(){
        return self::query()->select('id',app()->getLocale().'_name as name',
            app()->getLocale().'_info as info','image','cover','parent_id','profit_percentage','status')
            ->where('status','=',1);
    }

    public static function whereCat($name){
        return self::selection()
            ->whereRaw('(ar_name = "'.$name.'" OR en_name = "'.$name.'" ) ');
    }

    public static function cat_branches($cat_id , $ad_status = false){
        return self::selection()
            ->whereRaw('parent_id  =  '.$cat_id)
            ->when($ad_status == true , function ($e){
               $e->where('ar_name','=','اعلانات');
            })->when($ad_status == false , function ($e){
                $e->where('ar_name','!=','اعلانات');
            });
    }

    public  function branches(){
        return $this->hasMany(categories::class,'parent_id');
    }

    public  function  parent(){
        return $this->belongsTo(categories::class,'parent_id');
    }

    public function products(){
        return $this->hasMany(products::class,'category_id');
    }

    public function questions(){
        return $this->hasMany(categories_questions::class,'category_id');
    }

}
