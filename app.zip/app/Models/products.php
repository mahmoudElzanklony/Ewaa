<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class products extends Model
{
    use HasFactory;

    protected $table = 'products';

    protected $fillable = ['user_id','category_id','ar_name','ar_info',
        'en_name','en_info','guide',
        'price','in_stock','price_in_points','points','discount',
        'start_discount_date','end_discount_date',
        'status','approval'];


    protected $appends = ['average_rate'];

    public static function selection(){
        return self::query()->select('id','user_id','category_id',
            app()->getLocale().'_name as name',app()->getLocale().'_info as info',
           'guide',
           'price','in_stock','price_in_points','points','discount',
            'start_discount_date','end_discount_date',
            'status','approval','created_at');
    }

    public  function user(){
        return $this->belongsTo(User::class,'user_id');
    }
    public  function  category(){
        return $this->belongsTo(categories::class,'category_id');
    }
    public function product_images(){
        return $this->hasMany(products_images::class,'product_id');
    }
    public function product_first_image(){
        return $this->hasOne(products_images::class,'product_id');
    }

    public function comments(){
        return $this->hasMany(comments::class,'product_id');
    }

    public function product_answers(){
        return $this->hasMany(products_answers::class,'product_id');
    }

    public function orders(){
        return $this->hasMany(orders::class,'product_id');
    }
    public function rate(){
        return $this->hasMany(rates::class,'product_id');
    }

    public function three_info(){
        return $this->hasOne(products_three_info::class,'product_id');
    }

    public function getAverageRateAttribute()
    {
        return $this->attributes['average_rate'] = $this->rate->avg('star');
    }


}
