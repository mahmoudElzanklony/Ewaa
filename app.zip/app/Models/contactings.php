<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class contactings extends Model
{
    use HasFactory;

    protected $fillable = ['sender_id','receiver_id','type','message','seen'];

    public function user_sender(){
        return $this->belongsTo(User::class,'sender_id');
    }
    public function user_receiver(){
        return $this->belongsTo(User::class,'receiver_id');
    }

    public static function my_inbox(){
        return self::query()
            ->where('sender_id','=',auth()->user()->id)
            ->orWhere('receiver_id','=',auth()->user()->id);
    }

    public static function my_unseen_data($user_id){
        return DB::select(('SELECT type , COUNT(id) as sum_inbox FROM `contactings`
WHERE  receiver_id = '.$user_id.' and seen = 0 GROUP BY type;
'));
    }

    public static function my_unseen_data_dashboard($sender_id = 0){
        if($sender_id > 0){
            return DB::select('SELECT type , COUNT(id) as sum_inbox FROM `contactings` WHERE  sender_id = '.$sender_id.' and seen = 0 GROUP BY type');
        }else{
            return DB::select('SELECT type , COUNT(id) as sum_inbox FROM `contactings` WHERE  sender_id NOT IN  (SELECT id FROM users WHERE type = "admin") and seen = 0 GROUP BY type');
        }
    }

}
