<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class categories_questions extends Model
{
    use HasFactory;

    protected $fillable = ['category_id','ar_question','en_question','type'];

    public static function selection(){
        return self::query()->select('id','category_id',app()->getLocale().'_question as question');
    }

    public function has_answers(){
        return $this->hasMany(products_answers::class,'question_id');
    }
    public function category(){
        return $this->belongsTo(categories::class,'category_id');
    }
}
