<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class orders_promo_code extends Model
{
    use HasFactory;

    protected $table = 'orders_promo_code';

    protected $fillable = ['order_id','promo_code_ar_name','promo_code_en_name','old_price','new_price'];
}
