<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class order_piece_data extends Model
{
    use HasFactory;

    protected $table = 'order_piece_data';

    protected $fillable = ['order_id','color','size','info'];
}
