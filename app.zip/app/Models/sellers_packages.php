<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class sellers_packages extends Model
{
    use HasFactory;

    protected $fillable = ['user_id','package_id','admin_control','store_name','store_address','store_image'];

    public function package(){
        return $this->belongsTo(packages::class,'package_id');
    }

    public function user(){
        return $this->belongsTo(User::class,'user_id');
    }
}
