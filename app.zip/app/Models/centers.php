<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class centers extends Model
{
    use HasFactory;

    protected $fillable = ['city_id','ar_name','en_name','delivery'];

    public static function selection(){
        return self::query()->select('id','city_id','delivery',app()->getLocale().'_name as name');
    }
}
