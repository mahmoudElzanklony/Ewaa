<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class products_answers extends Model
{
    use HasFactory;

    protected $fillable = ['product_id','question_id','answer','price'];

    protected $appends = ['question_name'];

    public function question(){
        return $this->belongsTo(categories_questions::class,'question_id');
    }

    public function getQuestionNameAttribute()
    {
        $name = app()->getLocale().'_question';
        return $this->attributes['question_name'] = $this->question->$name;
    }
}
