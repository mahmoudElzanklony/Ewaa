<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UsersValidation extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */

    public function onLogin(){
        return [
            'phone'=>'required|max:191',
            'password'=>'required|max:191',
        ];
    }

    public function onRegister(){
        return [
            'username'=>'required',
            'phone'=>'required|min:11|unique:users,phone',
            'email'=>'required|max:191|unique:users',
            'password'=>'required|max:191',
            'type'=>'required',
        ];
    }

    public function onUpdateProfile(){
        return [
            'username'=>'required|max:191',
            'phone'=>'required|max:191|unique:users,phone,'.$this->id.',id',
            'address'=>'required|max:191',
        ];
    }



    public function rules()
    {
        if(request()->getRequestUri() == '/auth/login' || request()->getRequestUri() == '/api/auth/login'){
          return $this->onLogin();
        }else if(request()->getRequestUri() == '/user/updateprofile' || request()->getRequestUri() == '/api/user/updateprofile') {
           return $this->onUpdateProfile();
        }else{
           return $this->onRegister();
        }
    }

    public function messages()
    {
        return [
            'phone.min'=>trans('validation.min'),
            'phone.required'=>trans('validation.required'),
            'phone.max'=>trans('validation.max'),
            'phone.unique'=>trans('validation.unique'),
            'email.required'=>trans('validation.required'),
            'email.unique'=>trans('validation.unique'),
            'type.required'=>trans('validation.required'),
        ];
    }

    public function attributes()
    {
        return [
          'phone'=>trans('keywords.phone'),
          'email'=>trans('keywords.email'),
          'password'=>trans('keywords.password'),
          'type'=>trans('keywords.user_type'),
        ];
    }
}
