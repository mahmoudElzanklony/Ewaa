<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class seller_package_info extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */

    public function saveNewSeller(){
        return [
            'user_id'=>'required|Number|exists:users,id',
            'package_id'=>'required|Number|exists:packages,id',
            'admin_control'=>'required',
            'store_name'=>'required|max:191',
            'store_address'=>'required|max:191',
            'store_image'=>'required',
        ];
    }

    public function updateInfo(){
        return [
            'store_name'=>'required|max:191',
            'store_address'=>'required|max:191',
            'store_image'=>'nullable',
        ];
    }

    public function rules()
    {
        if(request()->getRequestUri() == '/auth/register'){
            return $this->saveNewSeller();
        }else{
            return $this->updateInfo();
        }
    }

    public function messages()
    {
        return [
            'user_id'=>trans('inputs.username'),
            'package_id'=>trans('inputs.package'),
            'admin_control'=>trans('inputs.admin_control'),
            'store_image'=>trans('keywords.commercial_register_photo'),
        ];
    }
}
