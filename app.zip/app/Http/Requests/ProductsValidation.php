<?php

namespace App\Http\Requests;

use App\Models\orders;
use App\Models\packages;
use App\Models\products;
use App\Models\sellers_packages;
use Illuminate\Foundation\Http\FormRequest;

class ProductsValidation extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        if(auth()->user()->type == 'seller') {
            $products = products::where('user_id', '=', auth()->user()->id)->get();
            $active_products = products::where('user_id', '=', auth()->user()->id)->where('status','=',1)->count();
            $products_ids = [];
            foreach($products as $pro){
                array_push($products_ids,$pro->id);
            }
            $orders = orders::whereIn('product_id',$products_ids)->count();
            if(request()->getRequestUri() == '/profile/createproduct'){
                // detect my package
                $package = sellers_packages::where('user_id','=',auth()->user()->id)->with('package')->first();
                if ($active_products < $package->package->no_products) {
                    return true;
                } else {
                    return false;
                }
            }else{
                return true;
            }

        }else{
            return true;
        }
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */

    public function onCreate(){
        return [
            'user_id'=>'required|max:191',
            'ar_name'=>'required|max:191',
            'en_name'=>'required|max:191',
            'ar_info'=>'required',
            'en_info'=>'required',
            'price'=>'required',
            'in_stock'=>'required',
            'status'=>'required',
        ];
    }




    public function rules()
    {
        if(request()->getRequestUri() == '/profile/saveproduct' ||
            request()->getRequestUri() == '/api/products/save-product?lang=ar' ||
            request()->getRequestUri() == '/api/products/save-product?lang=en'){
            return $this->onCreate();
        }
    }

    public function messages()
    {
        return [
            'user_id.required'=>trans('validation.required'),
            'ar_name.required'=>trans('validation.required'),
            'en_name.required'=>trans('validation.required'),
            'ar_info.required'=>trans('validation.required'),
            'en_info.required'=>trans('validation.required'),
            'price.required'=>trans('validation.required'),
            'status.required'=>trans('validation.required'),
        ];
    }

    public function attributes()
    {
        return [
            'user_id'=>trans('inputs.seller'),
            'ar_name'=>trans('inputs.ar_product_name'),
            'en_name'=>trans('inputs.en_product_name'),
            'ar_info'=>trans('inputs.ar_product_info'),
            'en_info'=>trans('inputs.en_product_info'),
            'price'=>trans('inputs.product_price'),
            'status'=>trans('inputs.product_status'),
        ];
    }
}
