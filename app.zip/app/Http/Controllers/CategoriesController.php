<?php

namespace App\Http\Controllers;

use App\Http\Controllers\classes\categories\FindCategory;
use App\Models\categories;
use App\Models\website_header;
use Illuminate\Http\Request;
use Inertia\Inertia;
use App\Models\products;
use App\Http\traits\lang_keywords;


class CategoriesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    use lang_keywords;
    public function index()
    {
        //
        $header = website_header::selection()->first();
        $cateories = categories::selection()->where('parent_id','=',null)->get();
        $description = '';
        foreach($cateories as $pack){
            $description .= $pack->info.' و ';
        }
        $keywords = '';
        foreach($cateories as $pack){
            $keywords .= $pack->name.' , ';
        }
        $keywords_data = $this->get_keywords(['website_name','website_categories','home','categories','offers','explore_products','input_search']);

        return Inertia::render('categories',[
            'name'=>'main',
            'ads'=>'',
            'category'=>'',
            'data'=>$cateories,
            'header'=>$header,
            'products_data' => [],
            'cat'=>'',
            'cats_search'=>[],
            'keywords'=>$keywords_data,
            'head_data'=>['title'=>'بنكسي | اقسامنا ','description'=>$description,'keywords'=>$keywords],
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $header = website_header::selection()->first();
        $id = str_replace('-',' ',$id);
        $id = categories::whereCat($id)->first();
        if($id == null){
            return back();
        }else{
            if($id->status == 0){
                return back();
            }
        }
        $ads = categories::selection()->with(['products'=>function($q){
            $q->where('approval','=',1)->with('product_images')->get();
        }])->where('parent_id','=',$id->id)
            ->where('ar_name','=','اعلانات')
            ->get();
        // check first there in ads in this category
        if(sizeof($ads) > 0){
            $ads =  $ads[0]->products;
        }
        // this is sub cats
        $branches = categories::cat_branches($id->id)->with('children')
            ->get();

        $cats_ids = [];
        if(sizeof($branches) > 0) {

            FindCategory::tree_cats($branches , $cats_ids);
            /*$products = products::selection()->with('product_first_image')
                ->whereIn('category_id', $cats_ids)->where('approval','=',1)
                ->where('status','=',1)->get();*/


        }else{
            $products = [];
            $cats_ids = [0];
        }

        $description = '';
        foreach($branches as $pack){
            $description .= $pack->info.' و ';
        }
        $keywords = '';
        foreach($branches as $pack){
            $keywords .= $pack->name.' , ';
        }
        $title = 'بنكسي  | منتجات قسم '.$id->name;
        $keywords_data = $this->get_keywords(['website_name','website_categories','home','categories',
            'offers','explore_products','input_search',
            'inner_categories','search_about_product','show_products','from_newest_to_oldest',
            'from_oldest_to_newest','price_category','lowest_value','highest_value','rates',
            'see_more','add_to_cart','arrow_direction','no_discount','no_items','buy','add',
            'to_cart','close','product_not_available','filter_products'
            ]);
        if($id) {
            return Inertia::render('categories', [
                'name' => 'sub',
                'ads'=>$ads,
                'category'=>$id,
                'data'=>$branches,
                'header'=>$header,
                'cats_search'=>$cats_ids,
                'cat'=>$id,
                'keywords'=>$keywords_data,
                'head_data'=>['title'=>$title,'description'=>$description,'keywords'=>$keywords],
            ]);
        }
    }



    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }


    public function allcats(){
        return categories::selection()->with('children',function($e){
            $e->select('id',app()->getLocale().'_name as name',
                app()->getLocale().'_info as info','image','cover','parent_id','profit_percentage','status')
                ->where('status','=',1)
                ->with('children',function($q){
                    $q->select('id',app()->getLocale().'_name as name',
                        app()->getLocale().'_info as info','image','cover','parent_id','profit_percentage','status')
                        ->where('status','=',1)
                        ->with('children');
                });
        })->where('parent_id','=',null)->orderBy('cat_order','ASC')->get();
    }

    public function getchilren(){
        $parent_id = request('parent_id');
        $output = categories::query()->select('id',app()->getLocale().'_name as name')
        ->where('parent_id',$parent_id)->where('status','=',1)->get()->reject(function ($e){
                return  $e->name == 'اعلانات';
            });
        return response()->json($output);
    }


    public function getparentcats(){
        $cats = categories::selection()->where('parent_id','=',null)->get();
        return response()->json($cats);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function search(){
        return FindCategory::search(request('name') , request('value'));

    }
}
