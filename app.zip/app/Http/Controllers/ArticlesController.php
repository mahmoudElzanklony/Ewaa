<?php

namespace App\Http\Controllers;

use App\Models\articles;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Inertia\Inertia;

class ArticlesController extends Controller
{


    private $posts;

    public function __construct(){
        $data = Http::get('https://my-json-server.typicode.com/typicode/demo/db')->json();

        $this->posts = collect($data);
    }
/*
    public function test(){
       // return $this->posts;
        return collect($this->posts['comments'])->mapWithKeys(function($val , $key){
             return $val;
        });


    }
*/

    public function articles(){
        $articles = articles::all();
        $description = '';
        $keywords = '';
        foreach ($articles as $a){
            $description .= $a->name. '  ';
            $keywords .= str_replace('-',',',$a->tags). '  ';
        }
        return Inertia::render('articles',[
            'articles'=>$articles,
            'head_data'=>['title'=>'بنكسي |  جميع المقالات ','description'=>$description,'keywords'=>$keywords],

        ]);
    }


    public function articleinfo(articles $id){

        return Inertia::render('articleinfo',[
           'info'=>$id,
            'head_data'=>['title'=>'بنكسي |   '.$id->name,'description'=>$id->name,'keywords'=>str_replace('-',',' , $id->tags)],

        ]);
    }

    public function deletearticle(){
        $id = request('id');
        $article = articles::where('id','=',$id)->first();
        if($article){
            $article->delete();
        }
        echo 1;
    }
    //
    public function addarticle(){
        if(auth()->check()) {
            if(auth()->user()->type == 'seller' || auth()->user()->type == 'client'){
                return redirect('/');
            }else {
                return Inertia::render('addarticle', [
                    'output' => null
                ]);
            }
        }else{
            return redirect('/');
        }
    }

    public function editarticle(articles $id){
        if(auth()->check()) {
            if(auth()->user()->type == 'seller' || auth()->user()->type == 'client'){
                return redirect('/');
            }else {
                return Inertia::render('addarticle',[
                    'output'=>$id
                ]);
            }
        }else{
            return redirect('/');
        }

    }

    public function save(){
        if(request()->has('id')){
            // edit
            // get element
            $article = articles::where('id','=',request('id'))->first();
            if($article){
                if(request()->has('image')) {
                    $this->validate(request(), [
                        'image' => 'image|mimes:png,jpg,gif,jpeg'
                    ]);
                    $file = request()->file('image');
                    $extension = $file->extension();
                    $image = 'image.' . date('y-m-d') . time() . rand(10, 999999) . '.' . $extension;
                    $file->move(public_path('images/articles'), $image);
                    $article->image = $image;
                }
                $article->name = request('name');
                $article->tags = request('tags');
                $article->editor = request('editor');
                $article->save();
            }
        }else{
            // create
            $this->validate(request(),[
               'image'=>'image|mimes:png,jpg,gif,jpeg'
            ]);
            $file = request()->file('image');
            $extension = $file->extension();
            $image = 'image.' . date('y-m-d') . time().rand(10,999999) . '.' . $extension;
            $file->move(public_path('images/articles'), $image);
            articles::create([
               'name'=>request('name'),
               'tags'=>request('tags'),
               'image'=>$image,
               'editor'=>request('editor'),
            ]);
        }
        echo json_encode(1);
    }
}
