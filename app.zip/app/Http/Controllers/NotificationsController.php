<?php

namespace App\Http\Controllers;

use App\Models\notifications;
use Illuminate\Http\Request;
use Inertia\Inertia;

class NotificationsController extends Controller
{
    //
    public function index(){
        $notifications = notifications::where('receiver_id','=',auth()->user()->id)->with('sender')->orderBy('id','DESC')->get();
        $no_unseen = notifications::where('receiver_id','=',auth()->user()->id)->where('seen','=',0)->count();
        return Inertia::render('notifications',[
            'notifications'=>$notifications,
            'no_unseen'=>$no_unseen,
        ]);
    }

    public function makeseen(){
        $notifications = notifications::where('receiver_id','=',auth()->user()->id)->with('sender')->update(['seen'=>1]);
        echo 1;
    }
}
