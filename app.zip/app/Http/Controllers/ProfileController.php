<?php

namespace App\Http\Controllers;

use App\Http\Controllers\classes\chat\seenmessages;
use App\Http\Controllers\classes\chat\send_message;
use App\Http\Controllers\classes\chat\un_seen_messages;
use App\Http\Controllers\classes\products\ProductMainColors;
use App\Http\Controllers\classes\products\SellerProducts;
use App\Http\Controllers\classes\products\UpdateProductPhotoData;
use App\Http\Controllers\classes\users\RateOrder;
use App\Http\Controllers\classes\users\UpdateProfileData;
use App\Http\Controllers\classes\users\user_favourites;
use App\Http\Controllers\classes\users\user_orders;
use App\Http\Controllers\classes\users\user_points;
use App\Http\Controllers\classes\users\user_questions_center;
use App\Http\Controllers\classes\users\user_rates;
use App\Http\Controllers\keywords_lang\CreateProductKeywords;
use App\Http\Controllers\keywords_lang\ProfileKeywords;
use App\Http\quick_helpers\messages_output;
use App\Http\quick_helpers\save_image_file;
use App\Http\Requests\ProductsValidation;
use App\Http\Requests\UsersValidation;
use App\Models\categories;
use App\Models\categories_questions;
use App\Models\contactings;
use App\Models\favourites;
use App\Models\notifications;
use App\Models\orders;
use App\Models\packages;
use App\Models\producrs_colors_sizes_photos;
use App\Models\products;
use App\Models\products_answers;
use App\Models\products_colors_sizes_photos;
use App\Models\products_images;
use App\Models\products_three_info;
use App\Models\rates;
use App\Models\sellers_packages;
use App\Models\User;
use Inertia\Inertia;
use Illuminate\Support\Facades\Hash;
use Image;
use App\Http\traits\lang_keywords;

class ProfileController extends Controller
{
    //
    use lang_keywords;
    public function index(){


        // get favourites
        $favourites = user_favourites::my_favs(auth()->user()->id);


        // if user is client
        if(auth()->user()->type != 'seller'){
        // get orders of this is client
            $orders = collect(user_orders::my_orders(auth()->user()->id))->unique('product.id');

            //return $orders;
            // get my points
            $points = user_points::my_points(auth()->user()->id);
            // get my rates
            $rates = user_rates::my_rates(auth()->user()->id);


            // question centers
            $user_questions_centers = user_questions_center::questions_center();

            // gey my contactings
            $contactings = contactings::my_inbox()->get();

            // unseen inbox
            $un_seen_data_inbox = un_seen_messages::un_seen_number();


            $output = [
                'orders'=>$orders,
                'rates'=>$rates,
                'favourites'=>$favourites,
                'points'=>$points,
                'contactings'=>$contactings,
                'user_questions_centers'=>$user_questions_centers,
                'un_seen_data_inbox'=>$un_seen_data_inbox,
            ];
        }else{
            // he is a seller

            // get number of products he is published
            $products = SellerProducts::myproducts(auth()->user()->id);

            // active number of  products
            $products_active = SellerProducts::activeProducts(auth()->user()->id);

            // get my orders sold
            $my_sellings = SellerProducts::orders_products(auth()->user()->id);


            // detect my package
            $package = sellers_packages::where('user_id','=',auth()->user()->id
            )->with('package:id,'.app()->getLocale().'_name as name,'.app()->getLocale().'_info as info,no_products,no_orders')->first();

            $output = [
                'products'=>$products,
                'active_products'=>$products_active,
                'my_sellings'=>$my_sellings,
                'favourites'=>$favourites,
                'package'=>$package->package
            ];

        }
        $keywords = new ProfileKeywords();


       return Inertia::render('profile',[
           'output'=>$output,
           'head_data'=>['title'=>'بنكسي | الملف الشخصي',
                        'description'=>'الملف الشخصي لكل عضو من اعضاء بنكسي وفيه كل بياناته وكل ما قاء به سيجده في صفحه الملف الشخصي ويستطيع التعديل عليها والحذف ايضا','keywords'=>'الملف الشخصي , بروفايلي في بنكسي , صفحتي الشخصيه , معلوماتي في بنكسي'],
           'keywords'=>$keywords->call_keywords(),

       ]);
    }

    public function createproduct(){
        if(auth()->user()->type != 'admin'){
            // get number of products active
            if(!$this->seller_has_permision()){
                return redirect('/profile')->with('message',trans('keywords.You_have_exceeded_the_number_of_active_products'));
            }
        }
        if(auth()->user()->block == 0) {
            $categories = categories::query()->select('id',app()->getLocale().'_name as name')
                ->where('parent_id','=',null)
                ->where('status','=',1)
                ->get();
            $keywords = new CreateProductKeywords();
            return Inertia::render('createproduct', [
                'categories' => $categories,
                'keywords'=>$keywords->call_keywords(),
                'colors'=>$keywords->colors(),
                'another_lang'=>app()->getLocale() == 'ar' ? 'en':'ar',
            ]);
        }else{
            session()->flash('message',trans('keywords.not_accepted_permission'));
            return redirect('/profile');
        }
    }
    // get sub cats of main category
    public function detectdataofcategory(){
        $main_cat = request('cat_id');

        $sub_cats_info =  categories::selection()->where('id', '=', request('cat_id'))
            ->with('branches')->first()->branches;
        $sub_cats_ids = [];
        foreach($sub_cats_info as $cat){
            array_push($sub_cats_ids,$cat->id);
        }
        // add category id to sub cats
        array_push($sub_cats_ids,request('cat_id'));
        // questions of main category
        $questions = categories_questions::selection()->whereIn('category_id',$sub_cats_ids)->get();


        // sub categories
        $sub_cats = categories::selection()->where('parent_id','=',$main_cat)->get();
        $output = [
          'sub_cats'=>$sub_cats,
          'questions'=>$questions,
        ];
        return response()->json($output);
    }

    // search in my sellings between date to date
    public function searchsellings(){
        $my_sellings = orders::with(['order_piece_data','orders_promo_code','product'=>function($q){

            $q->select('id','user_id','category_id',
                app()->getLocale().'_name as name',app()->getLocale().'_info as info',
                'guide',
                'price','in_stock','price_in_points','points','discount',
                'start_discount_date','end_discount_date',
                'status','approval')->with('product_first_image','category')
                ->with(['product_first_image','category','rate'])->with(['product_first_image','category'=>function($e) {
                    $e->select('id', app()->getLocale() . '_name as name', app()->getLocale() . '_info as info','profit_percentage');
                }]);
        },'rate'])->whereHas('product',function($q){
            $q->where('products.user_id','=',auth()->user()->id);
        })->whereBetween('created_at',[request('from'),request('to')])->get();
        echo json_encode($my_sellings);
    }


    public function seller_has_permision(){
        if(auth()->user()->type == 'seller') {
            $products = products::where('user_id', '=', auth()->user()->id)->get();
            $active_products = products::where('user_id', '=', auth()->user()->id)->where('status', '=', 1)->count();
            $products_ids = [];
            foreach ($products as $pro) {
                array_push($products_ids, $pro->id);
            }
            $orders = orders::whereIn('product_id', $products_ids)->count();
            // detect my package
            $package = sellers_packages::where('user_id', '=', auth()->user()->id)->with('package')->first();
            if ($active_products < $package->package->no_products) {
                $status = true;
            } else {
                $status = false;
            }
        }else{
            $status = true;
        }
        return $status;
    }

    public function saveproduct(ProductsValidation $productsValidation){

         // you have multi category in array
        // last one will be category_id
        $cats = request('main_category_id');
        // store remaing data of product
        $validated_data_product = $productsValidation->validated();
        $validated_data_product['category_id'] = end($cats);
        if(auth()->user()->type == 'seller' && !(request()->filled('id'))) {
            $validated_data_product['approval'] = 0;
        }

        if(auth()->user()->type == 'admin') {
            unset($validated_data_product['user_id']);
        }

        if(request()->filled('discount')){
            $validated_data_product['discount'] = request('discount');
            $validated_data_product['start_discount_date'] = request('start_discount_date');
            $validated_data_product['end_discount_date'] = request('end_discount_date');
        }

        if (request()->hasFile('guide')) {
            $file = request()->file('guide');
            $extension = $file->extension();
            $image = time().'_'.rand(0,99999999).'.'.$extension;
            $file->move(public_path('images/products'), $image); // uploaded it at folder
            $validated_data_product['guide']= $image;
        }

        // check if update of create
        $product = products::query()->updateOrCreate([
            'id'=>request()->filled('id') ? request('id') : null
        ],$validated_data_product);

        //update of create product three
        if(request('commercial_sale_status') == 1) {
            $three_data = [
                'ar_info' => request('ar_three_info'),
                'en_info' => request('en_three_info'),
                'price' => request('price_three'),
                'in_stock' => request('three_in_stock'),
                'discount' => request()->filled('discount_three') ? request('discount') : 0,
                'start_discount_date_three' => request()->filled('discount_three') ? request('start_discount_date_three') : null,
                'end_discount_date_three' => request()->filled('discount_three') ? request('end_discount_date_three') : null,
            ];
            $product_three = products_three_info::query()->updateOrCreate([
                'product_id' => request()->filled('id') ? request('id') : $product->id
            ], $three_data);
        }

            // insert images
            $photos_sizes_colors = json_decode(request('photo_sizes_colors'));
            $product_colors = ProductMainColors::my_colors($product->id);

            // product_colors  =============> main product colors
            $user_updated_colors = [];
            foreach($photos_sizes_colors as $it){
                array_push($user_updated_colors,$it->color);
            }
            // $user_updated_colors ===========> updated colors
            if (request()->hasFile('images')) {
                $files = request()->file('images');
                // delete all photos
                // products_images::query()->where('product_id',$product->id)->delete();

                foreach ($files as $file) {
                    $old_name = $file->getClientOriginalName();
                    $extension = $file->extension();
                    $image = time().'_'.rand(0,99999999).'.'.$extension;
                    $file->move(public_path('images/products'), $image); // uploaded it at folder
                    foreach($photos_sizes_colors as $item){
                        $colors = $item->color;
                        $sizes = implode(',',$item->sizes);
                        // if update then update old sizes
                        // this is because if i have  1xl , 2xl
                        // then updated it to 1xl , 2xl , 3xl
                        // i will make a new with new size
                        // and update previous

                        if(request()->filled('id')){
                            UpdateProductPhotoData::updateColor
                            (request('id'),$product_colors,$user_updated_colors,$colors,$sizes , $item->color_ids);
                        }
                        if(sizeof($item->photos) > 0) {
                            foreach ($item->photos as $photo) {
                                // get photo name that is uploaded
                                if ($photo == $old_name) {
                                    $photo = $image;
                                    products_images::query()->create([
                                        'product_id' => $product->id,
                                        'image' => $photo,
                                        'colors' => $colors,
                                        'sizes' => $sizes,
                                    ]);
                                }
                            }
                        }
                    }
                }
            }else{
                // no files updated
                // update only



                foreach($photos_sizes_colors as $item){
                    // check if color i had is equal to user sent
                    $colors = $item->color;
                    $colors_ids = $item->color_ids;
                    $sizes = implode(',',$item->sizes);
                    $product_id = request('id');
                    UpdateProductPhotoData::updateColor
                    (request('id'),$product_colors,$user_updated_colors,$colors,$sizes,$colors_ids);

                }
            }
        echo json_encode(true);
    }

    public function updatesize(){
        $product_sizes = products_images::query()
            ->where('product_id','=',request('product_id'))
            ->where('colors','=',request('color'))
            ->where('sizes','LIKE','%'.request('size').'%')
            ->get();
        foreach($product_sizes as $pro){
            if(request('operation') == 'delete'){
                $sizes =  str_replace(request('size'),'',$pro->sizes);
                $sizes =  preg_replace("/(.)\\1+/", "$1", trim($sizes,','));
                $pro->sizes = $sizes;
                $pro->save();
            }
        }
        return response()->json(true);
    }

    public function editproduct($id){

        $product = products::query()->where('id','=',$id)->with(['product_images','three_info','product_answers'=>function($q){
            $q->with('question');
        }])->first();


        if(!$product){
            return redirect('/profile');
        }
        if(!$this->seller_has_permision()){
            if(auth()->user()->type == 'seller'){
                if($product->status == 1){
                    $message = null;
                }else{
                    $message = 'سيتم اخفاء هذا المنتج تلقائيا لانك وصلت الي العدد المسموح للمنتجات النشطه في الباقه لديك ';
                }
            }else{
                $message = null;
            }
        }else{
            $message = null;
        }
        if($product->user_id == auth()->user()->id || auth()->user()->type == 'admin' || auth()->user()->type == 'employee') {
            $categories = categories::selection()
                ->where('ar_name','!=','اعلانات')
                ->where('parent_id', '=', null)->get();

            $parent_id = categories::where('id', '=', $product->category_id)->first()->parent_id;
            $sub = categories::selection()
                ->where('ar_name','!=','اعلانات')
                ->where('parent_id','=',$parent_id)->get();
            $keywords = new CreateProductKeywords();
            return Inertia::render('updateproduct', [
                'product' => $product,
                'categories' => $categories,
                'selected_parent_id' => $parent_id,
                'subs'=>$sub,
                'message'=>$message,
                'keywords'=>$keywords->call_keywords(),
                'colors'=>$keywords->colors(),
                'another_lang'=>app()->getLocale() == 'ar' ? 'en':'ar',
                'photos_sizes'=>$product->product_images->groupBy(['colors','sizes']),

            ]);
        }else{
            return redirect('/profile');
        }
    }
    public function updateproductinfo(){
        $product = products::query()->find(request('id'));
        if($product){
            if($product->user_id == auth()->user()->id){
                if(request()->filled('price')){
                    $product->price = request('price');
                }
                if(request()->filled('discount')){
                    $product->discount = request('discount');
                    $product->start_discount_date = request('start_discount_date');
                    $product->end_discount_date = request('end_discount_date');
                }
                if(request()->filled('in_stock')){
                    $product->in_stock = request('in_stock');
                }
            }
            $product->save();
        }
        $products = SellerProducts::myproducts(auth()->user()->id);
        return messages_output::success_message(['data'=>$products,'message'=>trans('keywords.updated_product_success')]);
    }

    public function deleteproductimage(){
        $image_id = request('id');
        $image = products_images::where('id','=',$image_id)->first();
        if($image){
            $image->delete();
        }
        echo 1;
    }

    public function deleteproduct(){
        $product = products::where('id','=',request('product_id'))->first();

        if($product){
            // check if there is any orders with this product
            $orders = orders::where('product_id','=',$product->id)->count();
            if($orders >  0){
                $msg = ['status'=>'error','message'=>'هناك اوردرات مرتبطه بهذا المنتج لذا لا تستطيع مسحه'];
            }else{
                $product->delete();
                $msg = ['status'=>'success','message'=>'تم مسح المنتج بنجاح'];
            }
        }else{
            $msg = ['status'=>'error','message'=>'لا يوجد معلومات عن هذا المنتج'];
        }


        echo json_encode($msg);
    }

    public function updateprofile(UsersValidation  $req){
        $data = UpdateProfileData::updateData($req,request());
        return $data;
    }

    public function rateproduct(){
        $data = request()->all();
        $data['user_id'] = auth()->user()->id;
        $points = RateOrder::rate_product($data);
        echo json_encode($points);
    }

    public function sendmsg(){
        return send_message::send(request());
    }

    public function seenmessages(){
        if(request()->filled('sender_id')) {
            return seenmessages::seenDashbaord(request('sender_id'), request('type'));
        }else{
            return seenmessages::seen(auth()->user()->id, request('type'));
        }
    }
}
