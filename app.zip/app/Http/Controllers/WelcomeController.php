<?php

namespace App\Http\Controllers;

use App\Http\Controllers\classes\users\user_questions_center;
use App\Models\categories;
use App\Models\contactings;
use App\Models\favourites;
use App\Models\features;
use App\Models\orders;
use App\Models\packages;
use App\Models\products;
use App\Models\products_answers;
use App\Models\sellers_packages;
use App\Models\SiteInfo;
use App\Models\website_header;
use Illuminate\Http\Request;
use Inertia\Inertia;
use \Illuminate\Support\Facades\DB;
use App\Http\traits\lang_keywords;

class WelcomeController extends Controller
{
    //
    use lang_keywords;
    public function index(){
        // get most 8 sold products
      /*  $best_sold = \App\Models\orders::with(['product'=>function ($q){
          $q->with('product_first_image');
        }])->groupBy('product_id')
                    ->selectRaw('sum(pieces) as sum_pieces , product_id')
                    ->orderBy('sum_pieces','DESC')->limit(8)->get();*/




        $best_sold = orders::with(['product'=>function($q){
            $q->select('id','user_id','category_id',
                app()->getLocale().'_name as name',app()->getLocale().'_info as info',
                'guide',
                'price','in_stock','price_in_points','points','discount',
                'start_discount_date','end_discount_date',
                'status','approval','created_at')
                ->with('product_first_image','product_images');
        }])->groupBy('product_id')->selectRaw('product_id,sum(pieces) as count')
            ->orderBy('count','DESC')
            ->limit(8)
            ->get();

        $last_products = products::selection()->with(['product_first_image','product_images'/*,'product_answers'=>function($e){
            $e->with('question')->get();
        }*/])->whereHas('category',function($q){
            $q->where('ar_name','!=','اعلانات');
        })
            ->addSelect([
                'fav'=>favourites::query()->whereColumn('products.id','favourites.product_id')
                      ->where('user_id',auth()->check() == 1 ? auth()->id():0)
                      ->latest()
                      ->limit(1)
                      ->select('product_id'),
            ])
            ->where('status','=',1)
            ->where('approval','=',1)
            ->orderBy('id','DESC')
            ->limit(8)
            ->get();

        $discount_products = products::selection()->with(['product_first_image','product_images'/*,'product_answers'=>function($e){
            $e->with('question')->get();
        }*/])->whereHas('category',function($q){
            $q->where('ar_name','!=','اعلانات');
        })
            ->addSelect([
                'fav'=>favourites::query()->whereColumn('products.id','favourites.product_id')
                    ->where('user_id',auth()->check() == 1 ? auth()->id():0)
                    ->latest()
                    ->limit(1)
                    ->select('product_id'),
            ])
            ->where('status','=',1)
            ->where('approval','=',1)
            ->where('discount','>',0)
            ->where('end_discount_date','>=',date('Y-m-d'))
            ->orderBy('id','DESC')
            ->limit(8)
            ->get();

        // return $last_products;
       /* $best_sold = orders::with(['product'=>function ($q) {

            $q->with('product_first_image');
        }])->get();*/

        $categories = categories::selection()->where('parent_id','=',null)->get();
     //   return $best_sold;

        $keywords = $this->get_keywords(['explore_categories','logout','login','website_name','categories',
            'best_seller','latest_products',
            'no_discount','no_items','buy','add','to_cart',
            'close','product_not_available',
            'see_more','add_to_cart','arrow_direction','bneksy_offers'
        ]);
        return Inertia::render('welcome',[
            'best_sold'=>$best_sold,
            'categories'=>$categories,
            'last_products'=>$last_products,
            'website'=>website_header::selection()->get(),
            'keywords'=>$keywords,
            'discount_products'=>$discount_products,
        ]);

    }


    public function getwebsiteinfo(){
        $info = website_header::selection()->first();
        $cats = categories::selection()->where('parent_id','=',null)->get();
        $keywords = $this->get_keywords(['website_name','quick_links','home','privacy_policy','who_us','categories',
                                        'latest_products','our_services','common_questions','contact_us','copy_right']);
        return response()->json(['info'=>$info->content,'cats'=>$cats,'keywords'=>$keywords]);
    }

    public function about(){
        $keywords = $this->get_text_keywords(['distinguishes','distinguishes_data','show_products','features',
            'free_shipping','free_shipping_text',
            'valuable_gifts','valuable_gifts_data','discount_coupons','discount_coupons_data','points_wallet',
            'points_wallet_data','product_preview','product_preview_data','support','support_data']);
        return Inertia::render('about',[
            'keywords'=>$keywords
        ]);
    }

    public function features(){
        $featrues = features::all();
        return Inertia::render('features',[
            'features'=>$featrues
        ]);
    }

    public function policy(){
        $info = SiteInfo::selection()->where('name','=','policy')->first();
        return Inertia::render('policy',[
            'head_data'=>['title'=>'سياسه الخصوصيه','description'=>'سياسه الخصوصيه لموقع بنكسي',
                'keywords'=>'سياسه الخصوصيه , سياسه بنكسي , سياسه الاستخدام'],
            'info'=>$info,
            'name'=>trans('keywords.privacy_policy'),
        ]);
    }

    public function sendmsg(){
        if(auth()->check()) {
            $data = request()->all();
            $data['user_id'] = auth()->user()->id;
            contactings::create($data);
            $output = ['icon'=>'success','title'=>'تم ارسال الرساله بنجاح الي الاداره'];
        }else{
            $output = ['icon'=>'error','title'=>'قم بتسجيل الدخول اولا'];

        }
        echo json_encode($output);
    }


    public function contactus(){

        $keywords = [
           'contact_us'=>trans('keywords.contact_us'),
           'message_type'=>trans('keywords.message_type'),
           'message_content'=>trans('keywords.message_content'),
           'problem_in_order'=>trans('keywords.problem_in_order'),
           'problem_in_delivery'=>trans('keywords.problem_in_delivery'),
           'problem_in_recovery'=>trans('keywords.problem_in_recovery'),
           'problem_in_product'=>trans('keywords.problem_in_product'),
           'problem_in_account'=>trans('keywords.problem_in_account'),
           'problem_in_payment'=>trans('keywords.problem_in_payment'),
           'send_now'=>trans('keywords.send_now'),
        ];
        $user_questions_centers = user_questions_center::questions_center();
        return Inertia::render('contactus',[
            'keywords'=>$keywords,
            'user_questions_centers'=>$user_questions_centers,

        ]);
    }
}
