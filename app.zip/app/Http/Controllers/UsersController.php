<?php

namespace App\Http\Controllers;

use App\Http\Controllers\classes\products\ProductComments;
use App\Http\Controllers\classes\sms\SMS_misr;
use App\Http\Controllers\classes\users\save_seller_package_info;
use App\Http\quick_helpers\messages_output;
use App\Http\Requests\UsersValidation;
use App\Http\services\Auth_Users;
use App\Models\categories;
use App\Models\categories_questions;
use App\Models\centers;
use App\Models\cities;
use App\Models\comments;
use App\Models\favourites;
use App\Models\marketer_info;
use App\Models\notifications;
use App\Models\packages;
use App\Models\products;
use App\Models\products_answers;
use App\Models\sellers_packages;
use App\Models\User;
use App\Http\Requests\seller_package_info;
use App\Models\users_points;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Laravel\Socialite\Facades\Socialite;
use Illuminate\Support\Facades\URL;
use Inertia\Inertia;
use App\Http\traits\lang_keywords;


class UsersController extends Controller
{
    //

    use lang_keywords;
    public function register(UsersValidation $val){
        return Auth_Users::register($val , request());
        // send notification to admin
      /* notifications::create([
            'sender_id'=> $user->id,
            'receiver_id'=>User::where('type','=','admin')->first()->id,
            'info'=>'تم انضمام عضويه جديده الي النظام',
            'url'=>'dashboard/users',
            'seen'=>0
        ]);*/


    }

    public function login(UsersValidation $res){
        if(auth()->attempt($res->validated()) ){
            $status = 1;
            $result = auth()->user();
            return  messages_output::success_message(['status'=>$status,'result'=>$result]);

        }else{
            $status = 0;
            $result = trans('errors.unauthenticated');
            return  messages_output::error_message(['status'=>$status,'result'=>$result]);

        }
    }

    public function resetpassword(){
        $description = 'تسجيل الدخول في بنكسي';
        $keywords = 'تسجيل الدخول  ,login , login to Bneksy';
        $keywords_data = $this->get_keywords(['login','phone','reset_password','register','enter_system_by_serial',
            'login','sign_up','sign_in','send_now','new_user_register','serial','forget_serial','send_serial']);

        return Inertia::render('resetpassword',[
            'head_data'=>['title'=>'بنكسي | الدخول عن طريق رقم التحقق',
                'description'=>$description,'keywords'=>$keywords,],
            'keywords_data'=>$keywords_data
        ]);
    }

    public function sendmailreset(){
        $user = User::where('phone','=',request('phone'))->first();
        if($user){
            if(request()->filled('serial')){
                if(request('serial') == $user->serial_number){
                    $status = 1;
                    auth()->login($user);
                }else{
                    $status = 0;
                }

            }else{
                $status = 0;
            }

        }else{
            $status = 0;
        }
        echo  json_encode($status);
        /*$user = User::where('email','=',request('email'))->first();
        if($user){
            $status = 1;
            $details = [
                'title' => 'reset passsword',
                'body' => 'please visit this url',
                'key'   =>$user->id .'/'. $user->password,
            ];

            \Mail::to($user->email)->cc()
                ->send(new \App\Mail\Myemail($details));

        }else{
            $status = 0;
        }
        echo  json_encode($status);*/

    }

    public function newreset(){
        $keywords_data = $this->get_keywords(['login','phone','reset_password','register','reset_serial','send_serial',
            'login','sign_up','sign_in','send_now','new_user_register','serial','have_serial','go_to_validate_serial']);

        return Inertia::render('newreset',[
            'keywords_data'=>$keywords_data
        ]);
    }

    public function sendserial(){
        if(request()->has('phone')){
            $user = User::where('phone','=',request('phone'))->first();
            if($user){
                if($user->phone == request('phone')){
                    $verify = 'رمز دخولك الي حسابك في موقع بنكسي في حاله نسيانك كلمه المرور هو '.$user->serial_number;
                    SMS_misr::send(['sms'=>$verify,'phone'=>$user->phone]);
                     $status = 1;
                }else{
                    $status = 0;
                }
            }else{
                $status = 0;
            }
        }else{
            $status = 0;
        }
        echo json_encode($status);
    }

    public function facebooksignin(){
        $type = explode('/',request()->path())[0];

        session()->put('fb_type',$type);

        return Socialite::driver('facebook')->stateless()->redirect();
    }

    public function facebooksigninredirect(){

        $type = explode('/',URL::previous())[3];
        $user = Socialite::driver('facebook')->stateless()->user();
        if(session()->get('fb_type') == "signin") {
            $check_user = User::where('email', '=', $user->email)->first();
            if ($check_user) {
                Auth::login($check_user);
                return redirect('/');
            } else {
                return Inertia::render('login', [
                    'hide_error' => 0
                ]);
            }
        }else{
            return Inertia::render('register', [
                'outcoming_data' => $user
            ]);
        }
        session()-forget('fb_type');
    }




    /*---------------------------start of user actions--------------------------------- */
    public function addtofav(){
        $product = products::where('id','=',request('product_id'))->first();
        // check if this product exists
        if($product != null){
            // check if user has this product in it's favourite
            $fav_user = favourites::where('user_id','=',auth()->user()->id)
                ->where('product_id','=',$product->id)->first();
            if($fav_user == null){
                // user has not this product in it's favourite
                favourites::create([
                    'user_id'=>auth()->user()->id,
                    'product_id'=>request('product_id')
                ]);
                $data = [
                    'status'=>1,
                    'icon'=>'success',
                    'fav_status'=>1,
                    'msg'=> trans('keywords.added_to_fav'),
                ];
            }else{
                // user has this product in it's favourite
                $fav_user->delete();
                $data = [
                    'status'=>1,
                    'icon'=>'success',
                    'fav_status'=>0,
                    'msg'=> trans('keywords.removed_from_fav'),
                ];
            }

        }else{
            $data = [
                'status'=>0,
                'icon'=>'error',
                'msg'=> 'لم يتم اضافه المنتج الي المفضله بنجاح'
            ];
        }
        echo json_encode($data);
    }

    public function checkfav()
    {
        if(auth()->check()){
            if(request()->has('product_id')){
                $product = products::where('id','=',request('product_id'))->first();
                // check if user has this product
                $fav_check = favourites::where('user_id','=',auth()->user()->id)
                    ->where('product_id','=',$product->id)->first();
                if($fav_check == null){
                    // user hasn't this product in it's favourite
                    $status = 0;
                }else{
                    $status = 1;
                }
            }else{
                $status = 0;
            }
        }else{
            $status = 0;
        }
        echo $status;
    }


    public function sendcomment(){
        $result = ProductComments::insertComment(request('product_id'),request('comment'));
        echo json_encode($result);
    }

    public function deletecomment(){
        $status = ProductComments::deleteComment(request('comment_id'));
        if($status == 1){
            return messages_output::success_message(trans('keywords.delete_comment_success'));
        }else{
            return messages_output::error_message(trans('keywords.delete_comment_error'));
        }
    }

    public function chageproducttype(){
        $question_answer = products_answers::where([
            'product_id'=>request('product_id'),
            'question_id'=>request('question_id'),
            'answer'=>request('answer'),
        ])->first();
        $product = products::where('id','=',request('product_id'))->first();
        $output = 0;
        if($product->discount > 0){
            // there is discount
            // check if question answer of product has over price
            if($question_answer->price == null ){
                $output =  '';
            }else{
                $output =  $question_answer->price - ($question_answer->price * ($product->discount / 100));
            }
        }else{
            // no discount
            // check if question answer of product has over price
            if($question_answer->price == null ){
                $output =  '';
            }else{
                $output =  $question_answer->price;
            }
        }
        echo $output;

    }

    public function buy(){
        if(request('order_type') == 'piece'){
            $product = products::selection()
                ->with(['three_info','product_first_image'=>function($e){
                    $e->where('colors','=',request('color'))->limit(1);
                }])->where('id','=',request('product_id'))
                ->first();
        }else{
            $product = products::selection()->where('id','=',request('product_id'))
                ->with('three_info','product_first_image')
                ->first();
        }


        $main_cat = categories::where('id','=',$product->category_id)->first();

        if(request('order_type') == 'piece') {
            $price = $product->price - request('discount_check_value');
        }else{
            $price = $product->three_info->price - request('discount_check_value');
        }


        if(request()->filled('pieces')){

            if(
                (request('order_type') == 'piece'&& request()->pieces <= $product->in_stock) ||
                (request('order_type') == 'three'&& request()->pieces <= $product->three_info->in_stock)
            ){
                $data_result = [
                    'product'=>$product,
                    'total_price'=>$price * request('pieces'),
                    'pieces'=>request('pieces'),
                    'color'=>request('order_type') == 'piece' ? request('color'):'',
                    'sizes'=>request('order_type') == 'piece' ? request('sizes'):'',
                    'order_type'=>request('order_type'),
                    'info'=>request('info'),
                ];
                session()->push('products',$data_result);
                $output = messages_output::success_message(trans('keywords.added_to_cart_successfully'));
            }else{
                $output =messages_output::error_message(trans('keywords.not_available_product_pieces'));
            }
        }else{
            $output =messages_output::error_message(trans('keywords.pieces_input_valid'));
        }

        return $output;
    }


    public function getdatawhen(){
        if(request('table') == 'cities'){
            $data = cities::selectoin()->where('governate_id','=',request('governate_id'))->get();
        }else if(request('table') == 'centers'){
            $data = centers::selection()->where('city_id','=',request('city_id'))->get();
        }else{
            $data = [];
        }
        echo json_encode($data);
    }

}
