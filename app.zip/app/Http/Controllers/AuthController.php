<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Inertia\Inertia;
use App\Http\traits\lang_keywords;

class AuthController extends Controller
{
    //
    use lang_keywords;
    public function register()
    {
        $description = 'اذا كنت تريد الانضمام في بنكسي  لكي تستطيع عمليه الشراء ويأتيك اشعارات بشكل مستمر وتحصل علي عروض يمكنك الانضمام معنا من خلال ملئ بياناتك في تلك الصفحه';
        $keywords = 'مستخدم جديد , تسجيل عضويه جديد , register to benaksy';
        $keywords_data = $this->get_keywords(['register','personal_data','username','email','password','address','client','seller','marketer',
            'phone','store_name','store_address','user_type','commercial_register_photo','your_marketing_page_link','sign_using_facebook','do_you_have_account','login','sign_up','sign_in']);
        return Inertia::render('register',[
            'outcoming_data'=>null,
            'head_data'=>['title'=>'بنكسي | تسجيل عضويه جديده في بنكسي','description'=>$description,'keywords'=>$keywords],
            'keywords'=>$keywords_data,
        ]);
    }

    public function login(){
        $description = 'تسجيل الدخول في بنكسي ';
        $keywords = 'تسجيل الدخول  ,login , login to benaksy';
        $keywords_data = $this->get_keywords(['login','phone','password','sign_in',
            'sign_using_facebook','forget_password','new_member','create_new_account']);

        return Inertia::render('login',[
            'hide_error'=>1,
            'keywords'=>$keywords_data,
            'head_data'=>['title'=>'بنكسي | تسجيل الدخول ','description'=>$description,'keywords'=>$keywords],
        ]);
    }
}
