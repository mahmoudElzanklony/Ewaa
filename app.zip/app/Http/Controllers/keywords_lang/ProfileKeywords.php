<?php


namespace App\Http\Controllers\keywords_lang;
use App\Http\traits\lang_keywords;

class ProfileKeywords
{
    use lang_keywords;
    public function call_keywords(){
        return $this->get_keywords(['edit_my_info','seller_not_accepted_yet','my_products','my_sale'
            ,'current_package','favourite','no_address','seller','please_update_your_info'
            ,'my_rates','complaints','my_points','add_product',
            'see_more','add_to_cart','arrow_direction','no_discount','no_items','buy','add','to_cart',
            'close','product_not_available',
            'product_name','category','price','client_rate','order_status','info_about_request','admin_profit',
            'my_profit','profit_status','not_yet_rated','see_info',
            'search_from_to_profit','search','points_earned','price_in_points','my_rate','payment_status',
            'rate_now','all_points','remaining_points',
            'edit_personal_info','username','leave_the_password_blank','address','phone','save','close',
            'see_request_info','product_info','client_choice','rate_product','bad','acceptable','good','v_good',
            'excellent','feedback','start_discount_date','end_discount_date','edit_product','start_discount_date',
            'end_discount_date','discount','in_stock','order_details','show','color','size','coupon','order_date',
            'old_price','new_price','order_info','order_type','pending','it_was_received','not_approval',
            'questions','coupon','problem_in_order','problem_in_delivery','problem_in_recovery','problem_in_product',
            'problem_in_account','problem_in_payment','questions_center','support_center'
            ,'select_support_type','write_your_message',
            'not_approved_yet','approved','my_deals',
        ]);
    }
}
