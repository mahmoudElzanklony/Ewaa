<?php


namespace App\Http\Controllers\keywords_lang;
use App\Http\traits\lang_keywords;

class CreateProductKeywords
{
    use lang_keywords;
    public function call_keywords(){
        return $this->get_keywords(['create_new_product',
            'product_info','items_in_stock',
            'product_name','add_new_price','add_price','add_another_value',
            'select_category','info_about_product','price_piece','discount_percentage','product_status',
            'start_date_discount','end_date_discount','in_stock','discount_three',
            'product_color','product_image','size','sizes','add_another_size','sizes_and_colors_and_photos_product',
            'three_info','price_three','three_in_stock','sell_by_piece','commercial_sale','photos_product',
            'available','not_available','create_new_product',
            'info_in_different_lang','product_name_differ_lang','product_info_differ_lang','product_info_three_differ_lang',
            'start_discount_date','end_discount_date','active','hidden_product','important_time',
            'product_guide_differ_lang','product_guide','update_product','see_photo_full_screen','close',
            'are_you_sure_to_delete','ok','cancel','deleted_success'
        ]);
    }

    public function colors(){
        return ['red','yellow','orange','black','gray','brown','green','white','blue','purple','pink','khaki'];
    }
}
