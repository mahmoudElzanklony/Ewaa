<?php


namespace App\Http\Controllers\keywords_lang;


use App\Http\traits\lang_keywords;

class ProductDetailsKeywords
{
    use lang_keywords;
    public function my_keywords(){
        return $this->get_keywords(['add_to_favourite','another_info_product','not_available_product','color','sizes',
            'product_date','home','categories','remove_from_favourite','no_discount','info_features_about_product',
            'no_items','rates','comments','info_about_seller','from_most','client','write_comment_here','number_of_products_published',
            'no_orders','average_rates','seller_rank','colors','items_in_stock','end_discount_date',
            'available_colors_sizes','product_guide','make_comment_success','access_buy_three','access_buy_piece',
            'order_info','buy','join_date','seller_name','close','add_to_cart'
        ]);
    }
}
