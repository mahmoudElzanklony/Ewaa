<?php

namespace App\Http\Controllers;

use App\Http\Controllers\classes\checkout\KeyWordsData;
use App\Http\Controllers\classes\checkout\Payment;
use App\Http\Controllers\classes\checkout\PaymentUser;
use App\Http\Controllers\classes\checkout\validatePromoCode;
use App\Models\governates;
use App\Models\notifications;
use App\Models\order_piece_data;
use App\Models\orders;
use App\Models\orders_clinets_choices;
use App\Models\orders_promo_code;
use App\Models\packages;
use App\Models\products;
use App\Models\products_answers;
use App\Models\sellers_packages;
use App\Models\User;
use App\Models\users_points;
use App\Models\users_promo_codes;
use Inertia\Inertia;

class CheckoutController extends Controller
{
    //




    function initiatePayment($apiURL, $apiKey, $postFields) {
        $json = $this->callAPI("$apiURL/v2/InitiatePayment", $apiKey, $postFields);
        return $json->Data->PaymentMethods;
    }

    //------------------------------------------------------------------------------
    /*
    * Execute Payment Endpoint Function
    */

    function executePayment($apiURL, $apiKey, $postFields) {

        $json = $this->callAPI("$apiURL/v2/ExecutePayment", $apiKey, $postFields);
        return $json->Data;
    }

    //------------------------------------------------------------------------------
    /*
    * Call API Endpoint Function
    */

    function callAPI($endpointURL, $apiKey, $postFields = [], $requestType = 'POST') {
        $curl = curl_init($endpointURL);
        curl_setopt_array($curl, array(
            CURLOPT_CUSTOMREQUEST  => $requestType,
            CURLOPT_POSTFIELDS     => json_encode($postFields),
            CURLOPT_HTTPHEADER     => array("Authorization: Bearer $apiKey", 'Content-Type: application/json'),
            CURLOPT_RETURNTRANSFER => true,
        ));

        $response = curl_exec($curl);
        $curlErr  = curl_error($curl);

        curl_close($curl);

        if ($curlErr) {
            //Curl is not working in your server
            die("Curl Error: $curlErr");
        }

        $error = $this->handleError($response);
        if ($error) {
            die("Error: $error");
        }

        return json_decode($response);
    }

    //------------------------------------------------------------------------------
    /*
    * Handle Endpoint Errors Function
    */

    function handleError($response) {

        $json = json_decode($response);
        if (isset($json->IsSuccess) && $json->IsSuccess == true) {
            return null;
        }

        //Check for the errors
        if (isset($json->ValidationErrors) || isset($json->FieldsErrors)) {
            $errorsObj = isset($json->ValidationErrors) ? $json->ValidationErrors : $json->FieldsErrors;
            $blogDatas = array_column($errorsObj, 'Error', 'Name');

            $error = implode(', ', array_map(function ($k, $v) {
                        return "$k: $v";
                    }, array_keys($blogDatas), array_values($blogDatas)));
        } else if (isset($json->Data->ErrorMessage)) {
            $error = $json->Data->ErrorMessage;
        }

        if (empty($error)) {
            $error = (isset($json->Message)) ? $json->Message : (!empty($response) ? $response : 'API key or API URL is not correct');
        }

        return $error;
    }


    public function myfatoura(){

        /* ------------------------ Configurations ---------------------------------- */
        //Test
        $apiURL = 'https://apitest.myfatoorah.com';
        $apiKey = 'hiCmj3fhJcENOEXb4rmD9txOgjEX_0tIv31AiUvKtGfTanf1yf8yhgNW6-a329RTwvluATKYFcY8oNk4ji5iHD24RNM4plOExgwG06hIbzsfzflyz-gpjYVtgLIo0-b08TPaXbs_VnSoxCmVlzkxdkJ3Yqe0GDmVsfF4A7lZqBbk7zKB7_QwIWi_HQ1_BafN4Do2A7a7ze24hPdJttDy7f6h3GCNpoAYY4fz0ZhmQd7XuGbsl7UsRAEPAmGwEHBmowAXLw06NXaiBPAgzMu-IqPflvQdm992GfocixdE7MfGzork30IiksDX7L4igQcZVyugy1ppVbMTCZwGcjFqF6hirJFzA_Si59rUd-d0i0Vzm_vDgC9QVFPlJ5OnMvidlv0v7EEHlthvT6wzZqQqjkE6PEeYabxFBt9b2ptuOL21oDGka6Xle8IN-dWwavL5b5Gb2wCW2FpJqcA10KUL39p-IHYsvlUnhH5DboSReO1tr5GfvKLuuHMKEDaF3D8HzA5niZV1rm9-FmNsXhCUc4dHw5N4UTb3xV2M4CB8CnnU0iVQCrBhA0v3z-6o5rTg4dcgfKBMZ_RSl2fvrqtiBQt-9aFU3KBdk0iDe1SbIMd_wllnnXID2gA66Daib75QswrLFYtrG0KMiNYwGgwbPeRwGgBHk2CIbGDWULspO1DLfKCn74ws3QdVwNKteq5t4KC0JgB0mPl67z7Ofgh5WoF3sAM';
         //Live
        //$apiURL = 'https://api.myfatoorah.com';
        //$apiKey = ''; //Live token value to be placed here: https://myfatoorah.readme.io/docs/live-token


        /* ------------------------ Call InitiatePayment Endpoint ------------------- */
        //Fill POST fields array
        $ipPostFields = ['InvoiceAmount' => 100, 'CurrencyIso' => 'KWD'];

        //Call endpoint
        $paymentMethods = $this->initiatePayment($apiURL, $apiKey, $ipPostFields);

        //You can save $paymentMethods information in database to be used later
        foreach ($paymentMethods as $pm) {
            if ($pm->PaymentMethodEn == 'KNET') {
                $paymentMethodId = $pm->PaymentMethodId;
                break;
            }
        }

        //Fill invoice item array
        $invoiceItems[] = [
            'ItemName'  => 'iphone 11', //ISBAN, or SKU
            'Quantity'  => '2', //Item's quantity
            'UnitPrice' => '21000', //Price per item
            ];
        //Fill POST fields array
        $postFields = [
            //Fill required data
            'paymentMethodId' => $paymentMethodId,
            'InvoiceValue'    => '50',
            'CallBackUrl'     => 'http://127.0.0.1:8000',
            'ErrorUrl'        => 'http://127.0.0.1:8000', //or 'https://example.com/error.php'
                //Fill optional data
                //'CustomerName'       => 'fname lname',
                //'DisplayCurrencyIso' => 'KWD',
                //'MobileCountryCode'  => '+965',
                //'CustomerMobile'     => '1234567890',
                //'CustomerEmail'      => 'email@example.com',
                //'Language'           => 'en', //or 'ar'
                //'CustomerReference'  => 'orderId',
                //'CustomerCivilId'    => 'CivilId',
                //'UserDefinedField'   => 'This could be string, number, or array',
                //'ExpiryDate'         => '', //The Invoice expires after 3 days by default. Use 'Y-m-d\TH:i:s' format in the 'Asia/Kuwait' time zone.
                //'SourceInfo'         => 'Pure PHP', //For example: (Laravel/Yii API Ver2.0 integration)
                //'CustomerAddress'    => $customerAddress,
                //'InvoiceItems'       => $invoiceItems,
            ];
            //Call endpoint
            $data = $this->executePayment($apiURL, $apiKey, $postFields);
            //You can save payment data in database as per your needs
            $invoiceId   = $data->InvoiceId;
            $paymentLink = $data->PaymentURL;
           // dd($paymentLink);
            //Redirect your customer to the payment page to complete the payment process
            //Display the payment link to your customer
            return redirect($paymentLink);
           // echo "Click on <a href='$paymentLink' target='_blank'>$paymentLink</a> to pay with invoiceID $invoiceId.";
            die;


            /* ------------------------ Functions --------------------------------------- */
            /*
            * Initiate Payment Endpoint Function
            */

    }

    /* -------------------------------------------------------------------------- */


    private function getPaymentStatus($id, $resourcepath)
    {
        $url = "https://eu-test.oppwa.com/";
        $url .= $resourcepath;
        $url .= "?entityId=8a8294174b7ecb28014b9699220015ca";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Authorization:Bearer OGE4Mjk0MTc0YjdlY2IyODAxNGI5Njk5MjIwMDE1Y2N8c3k2S0pzVDg='));
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);// this should be set to true in production
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $responseData = curl_exec($ch);
        if(curl_errno($ch)) {
            return curl_error($ch);
        }
        curl_close($ch);
        return json_decode($responseData, true);

    }

    public function index(){
        if(request('id') && request('resourcePath')){
           $res =   $this->getPaymentStatus(request('id'), request('resourcePath'));
           return $res;
        }else{
            $res = '';
        }
        if(session()->get('products') == null){
            return redirect('/');
        }else{
            $keywords = new KeyWordsData();
            return Inertia::render('checkout',[
                'products'=>session()->get('products'),
                'res'=>$res,
                'governates'=>governates::selection()->get(),
                'head_data'=>['title'=>'بنكسي  | صفحه الدفع','description'=>'صفحه الدفع في بنكسي  لدفع جميع الاشياء التي قمت بشرائها','keywords'=>'صفحه الدفع , دفع في بنكسي  , checkout'],
                'keywords'=>$keywords->checkout_words(),
                'user_points'=>users_points::query()->where('user_id',auth()->user()->id)->first()->points,
                'products_points'=>collect(session()->get('products'))->sum('product.price_in_points'),
                'three_order_exist'=>collect(session()->get('products'))->contains('order_type','three'),
            ]);
        }
    }

    public function deleteitem(){
        if(session()->has('products')){
           // session()->forget(session()->get('products').[request('index')]);
           $products = session()->get('products'); // Get the array
           unset($products[request('index')]); // Unset the index you want
           session()->put('products', $products); // Set the array again
        }
    }




    public function validatepromocode(){
        return validatePromoCode::validatePromo(request('number'));
    }

    public function getform(){
        $form = view('ajax.initpayment')->with('res',request('res'))->render();
        echo json_encode($form);
    }

    public function payment()
    {
       $status = PaymentUser::cash_payment(request() , json_decode(request('products')));
        echo json_encode($status);
    }
}
