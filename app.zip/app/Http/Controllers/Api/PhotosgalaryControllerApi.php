<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\quick_helpers\messages_output;
use App\Models\website_header;
use Illuminate\Http\Request;

class PhotosgalaryControllerApi extends Controller
{
    //
    public function index(){
        if(request()->has('type')){
            return messages_output::success_message(website_header::selection()->get());
        }
    }
}
