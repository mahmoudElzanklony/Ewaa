<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\classes\sms\SMS_misr;
use App\Http\Controllers\Controller;
use App\Http\quick_helpers\messages_output;
use App\Http\Requests\UsersValidation;
use App\Http\services\Auth_Users;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    //
    public function register(UsersValidation $val){
        return Auth_Users::register($val , request());
        // send notification to admin
        /* notifications::create([
              'sender_id'=> $user->id,
              'receiver_id'=>User::where('type','=','admin')->first()->id,
              'info'=>'تم انضمام عضويه جديده الي النظام',
              'url'=>'dashboard/users',
              'seen'=>0
          ]);*/


    }

    public function login(){
        $data = Validator::make(request()->all(),[
            'phone'=>'required',
            'password'=>'required',
        ]);

        if(sizeof($data->errors()) == 0) {

            $credential = request()->only(['phone', 'password']);
            $token = auth('api')->attempt($credential);
            if(!$token){
                return messages_output::error_message(trans('errors.unauthenticated'));
            }else {
                $user = auth('api')->user();
                $user['token'] =  $token;
                return messages_output::success_message($user);
            }
        }else{
            return messages_output::error_message($data->errors());
        }
    }


    public function sendcode(){
        if(request()->has('phone')){
            $user = User::query()->where('phone','=',request('phone'))->first();
            if($user){
                $verify = 'رمز دخولك الي حسابك في موقع بنكسي في حاله نسيانك كلمه المرور هو '.$user->serial_number;
                SMS_misr::send(['sms'=>$verify,'phone'=>$user->phone]);
                return messages_output::success_message(1);
            }else{
                return messages_output::success_message(0);
            }
        }else{
            return messages_output::success_message('phone parameter has no value');
        }
    }

    public function loginbyserial(){
        if(request()->has('phone') && request()->has('serial')){
            $user = User::query()
                ->where('phone','=',request('phone'))
                ->where('serial_number','=',request('serial'))
                ->first();
            if($user){
                $user->password = bcrypt(request('new_password'));
                $user->save();
                return messages_output::success_message(trans('keywords.updated_success'));
                /*$token = auth('api')->login($user);
                if(!$token){
                    return messages_output::error_message(trans('errors.unauthenticated'));
                }else {
                    $user = auth('api')->user();
                    $user['token'] =  $token;
                    return messages_output::success_message($user);
                }*/
            }else{
                return messages_output::error_message(trans('keywords.not_found_user'));
            }
        }
    }

    public function logout(){
        $token = request('token');
        if($token){
            JWTAuth::invalidate($token); //logout

        }else{
            return messages_output::error_message('some thing go wrong');
        }
        return messages_output::success_message('log out successfully');
    }
}
