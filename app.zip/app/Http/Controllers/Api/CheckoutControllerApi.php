<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\classes\checkout\PaymentUser;
use App\Http\Controllers\classes\checkout\validatePromoCode;
use App\Http\Controllers\Controller;
use App\Http\quick_helpers\messages_output;
use App\Models\products;
use Illuminate\Http\Request;

class CheckoutControllerApi extends Controller
{
    //
    public function validatePromoCode(){
        if(request()->has('serial')) {
            return validatePromoCode::validatePromo(request('serial'));
        }
    }

    public function payment(){
        $products = request('products');
        foreach($products as $key => $item){
            $products[$key]['product'] =  products::selection()
                ->with(['three_info'])->where('id','=',$item['product_id'])
                ->first();
            $price = $products[$key]['product']['price'];
            if($item['pieces']){
                if(
                    ($item['order_type'] == 'piece'&& $item['pieces'] <= $products[$key]['product']->in_stock) ||
                    ($item['order_type'] == 'three'&& $item['pieces'] <= $products[$key]['product']->three_info->in_stock)
                ){
                    if($products[$key]['product']['start_discount_date'] != null){
                        if(date('Y-m-d') < date('Y-m-d', strtotime($products[$key]['product']['end_discount_date']))){
                            //echo not yet expired!
                            $discount = $products[$key]['product']['price'] *
                                $products[$key]['product']['discount'] / 100;
                            $price = $products[$key]['product']['price'] - $discount;
                        }
                    }
                    $products[$key]['total_price'] = $price * $item['pieces'];
                    $products[$key]['color'] =  $item['color'] ?? '';
                    $products[$key]['sizes'] =  $item['sizes'] ?? '';
                    $products[$key]['order_type'] =  $item['order_type'];
                    $products[$key]['info'] =  $item['info'] ?? '';

                }else{
                    unset($products[$key]);
                    continue;
                }
            }else{
                unset($products[$key]);
                continue;
            }
            // stock is okay.............. and found products in stock

        }
        if(sizeof($products) == 0){
            return messages_output::error_message(trans('keywords.not_found_in_stock'));
        }
       return PaymentUser::cash_payment(request(),json_decode(json_encode($products)));
    }
}
