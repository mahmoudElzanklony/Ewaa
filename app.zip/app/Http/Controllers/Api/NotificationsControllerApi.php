<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\quick_helpers\messages_output;
use App\Models\notifications;
use Illuminate\Http\Request;

class NotificationsControllerApi extends Controller
{
    //
    public function index(){
        return messages_output::success_message(notifications::query()
            ->where('receiver_id','=',auth()->user()->id)->get());
    }
}
