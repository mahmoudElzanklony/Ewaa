<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\classes\users\user_points;
use App\Http\Controllers\Controller;
use App\Http\quick_helpers\messages_output;
use App\Models\packages;
use Illuminate\Http\Request;

class UserControllerApi extends Controller
{
    //
    public function my_points(){
        return messages_output::success_message(user_points::my_points(auth()->user()->id));
    }

    public function info(){
        return messages_output::success_message(auth()->user());
    }


    public function packages(){
        return messages_output::success_message(packages::selection()->get());
    }
}
