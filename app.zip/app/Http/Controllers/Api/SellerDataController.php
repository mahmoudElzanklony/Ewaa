<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\classes\products\SellerProducts;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\quick_helpers\messages_output;

class SellerDataController extends Controller
{
    //
    public function my_products(){
        return messages_output::success_message(SellerProducts::myproducts(auth()->user()->id));
    }
    public function my_products_active(){
        return messages_output::success_message(SellerProducts::activeProducts(auth()->user()->id));
    }

    public function my_sold_products_orders(){
        return messages_output::success_message(SellerProducts::orders_products(auth()->user()->id));
    }
}
