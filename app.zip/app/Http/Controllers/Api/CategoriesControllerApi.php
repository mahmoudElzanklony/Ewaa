<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\quick_helpers\messages_output;
use App\Models\categories;
use Illuminate\Http\Request;

class CategoriesControllerApi extends Controller
{
    //
    public function index(){
        return messages_output::success_message(
            categories::selection()->when(request()->has('id'),function ($e){
                $e->where('id','=',request('id'));
            })->when(request()->has('type'),function ($e){
                $e->where('parent_id','=',null);
            })->when(request()->has('parent_id'),function ($e){
                $e->where('parent_id','=',request('parent_id'));
            })->orderBy('cat_order','ASC')->get()
        );
    }


}
