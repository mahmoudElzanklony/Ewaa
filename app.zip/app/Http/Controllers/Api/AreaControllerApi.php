<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\quick_helpers\messages_output;
use App\Models\centers;
use App\Models\cities;
use App\Models\governates;
use Illuminate\Http\Request;

class AreaControllerApi extends Controller
{
    //
    public function governates(){
        return messages_output::success_message(governates::selection()->get());
    }
    public function cities(){
        if(request()->has('governate_id')){
            return messages_output::success_message(cities::selectoin()->where('governate_id',request('governate_id'))->get());
        }
    }
    public function centers(){
        if(request()->has('city_id')){
            return messages_output::success_message(centers::selection()->where('city_id',request('city_id'))->get());
        }
    }
}
