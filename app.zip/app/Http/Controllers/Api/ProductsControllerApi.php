<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\classes\products\FindProducts;
use App\Http\Controllers\classes\products\ProductComments;
use App\Http\Controllers\classes\products\ProductMainColors;
use App\Http\Controllers\classes\products\UpdateProductPhotoData;
use App\Http\Controllers\classes\users\user_favourites;
use App\Http\Controllers\Controller;
use App\Http\quick_helpers\messages_output;
use App\Http\Requests\ProductsValidation;
use App\Models\categories;
use App\Models\comments;
use App\Models\favourites;
use App\Models\orders;
use App\Models\products;
use App\Models\products_images;
use App\Models\products_three_info;
use Illuminate\Http\Request;
use Tymon\JWTAuth\Facades\JWTAuth;

class ProductsControllerApi extends Controller
{
    //
    public function products(){
        if(request()->has('cat_id')){
            $cat = categories::query()->find(request('cat_id'));
            if($cat != null){
                return messages_output::success_message(
                    products::selection()
                        ->with(['comments','product_images','rate'=>function($e){
                            $e->with('user');
                        },'three_info'=>function($e){
                            $e->select('id','product_id',
                                app()->getLocale().'_info as info',
                                'price','in_stock','discount','start_discount_date_three','end_discount_date_three');
                        },'user'])
                        ->addSelect([
                            'fav'=>favourites::query()->whereColumn('products.id','favourites.product_id')
                                ->where('favourites.user_id','=',auth()->user()->id)
                                ->select('product_id')->latest()->limit(1)
                        ])
                        ->where('category_id','=',$cat->id)->get());
            }
        }
    }

    public function specific_product(){
        if(request()->has('id')){
            return messages_output::success_message(
                products::selection()->with(['user','comments','product_images',
                    'rate'=>function($e){
                        $e->with('user');
                    },'three_info'=>function($e){
                        $e->select('id','product_id',
                            app()->getLocale().'_info as info',
                            'price','in_stock','discount','start_discount_date_three','end_discount_date_three');
                    }])
                    ->addSelect([
                        'fav'=>favourites::query()->whereColumn('products.id','favourites.product_id')
                            ->where('favourites.user_id','=',auth()->user()->id)
                            ->select('product_id')->latest()->limit(1)
                    ])
                    ->where('id','=',request('id'))->first());
        }
    }

    public function best_discount(){
        $data =  products::selection()->with(['product_images','user'/*,'product_answers'=>function($e){
            $e->with('question')->get();
        }*/])->whereHas('category',function($q){
            $q->where('ar_name','!=','اعلانات');
        })
            ->addSelect([
                'fav'=>favourites::query()->whereColumn('products.id','favourites.product_id')
                    ->where('user_id',auth()->check() == 1 ? auth()->id():0)
                    ->latest()
                    ->limit(1)
                    ->select('product_id'),
            ])
            ->where('status','=',1)
            ->where('approval','=',1)
            ->where('discount','>',0)
            ->where('end_discount_date','>=',date('Y-m-d'))
            ->orderBy('id','DESC')
            ->limit(8)
            ->get();
        return messages_output::success_message($data);
    }

    public function best_sold(){
        $data =  orders::with(['product'=>function($q){
            $q->select('id','user_id','category_id',
                app()->getLocale().'_name as name',app()->getLocale().'_info as info',
                'guide',
                'price','in_stock','price_in_points','points','discount',
                'start_discount_date','end_discount_date',
                'status','approval','created_at')
                ->with('user','product_images');
        }])->groupBy('product_id')->selectRaw('product_id,sum(pieces) as count')
            ->orderBy('count','DESC')
            ->limit(8)
            ->get();
        return messages_output::success_message($data);
    }

    public function product_insert_comment(){
        $comment = request('comment');
        $product_id = request('product_id');
        if(request()->filled('id')){
            $id = request('id');
        }else{
            $id = false;
        }
        $product = products::query()->find($product_id);
        if($product != null){
            return messages_output::success_message(
                ProductComments::insertComment($product_id , $comment , false , $id)
            );
        }

    }

    public function product_delete_comment(){
        $comment_id = request('id');
        $comment = comments::query()->find($comment_id);
        if($comment != null){
            $comment->delete();
            return messages_output::success_message(trans('deleted_success'));
        }
    }




    public function save_product(ProductsValidation $productsValidation){

        // you have multi category in array
        // last one will be category_id
        $cat = categories::query()->find(request('category_id'));
        if($cat == null){
            return messages_output::error_message(trans('keywords.not_found_category'));
        }
        // store remaing data of product
        $validated_data_product = $productsValidation->validated();
        $validated_data_product['category_id'] = request('category_id');

        $validated_data_product['approval'] = 0 ;

        if(request()->filled('discount')){
            $validated_data_product['discount'] = request('discount');
            $validated_data_product['start_discount_date'] = request('start_discount_date');
            $validated_data_product['end_discount_date'] = request('end_discount_date');
        }


        if (request()->hasFile('guide')) {
            $file = request()->file('guide');
            $extension = $file->extension();
            $image = time().'_'.rand(0,99999999).'.'.$extension;
            $file->move(public_path('images/products'), $image); // uploaded it at folder
            $validated_data_product['guide']= $image;
        }

        // check if update of create
        $product = products::query()->updateOrCreate([
            'id'=>request()->filled('id') ? request('id') : null
        ],$validated_data_product);

        //update of create product three
        if(request('commercial_sale_status') == 1) {
            $three_data = [
                'ar_info' => request('ar_three_info'),
                'en_info' => request('en_three_info'),
                'price' => request('price_three'),
                'in_stock' => request('three_in_stock'),
                'discount' => request()->filled('discount_three') ? request('discount') : 0,
                'start_discount_date_three' => request()->filled('discount_three') ? request('start_discount_date_three') : null,
                'end_discount_date_three' => request()->filled('discount_three') ? request('end_discount_date_three') : null,
            ];
            $product_three = products_three_info::query()->updateOrCreate([
                'product_id' => request()->filled('id') ? request('id') : $product->id
            ], $three_data);
        }

        // insert images
        $photos_sizes_colors = json_decode(request('photo_sizes_colors'));
        $product_colors = ProductMainColors::my_colors($product->id);

        // product_colors  =============> main product colors
        $user_updated_colors = [];
        foreach($photos_sizes_colors as $it){
            array_push($user_updated_colors,$it->color);
        }
        // $user_updated_colors ===========> updated colors
        if (request()->hasFile('images')) {
            $files = request()->file('images');
            // delete all photos
            // products_images::query()->where('product_id',$product->id)->delete();

            foreach ($files as $file) {
                $old_name = $file->getClientOriginalName();
                $extension = $file->extension();
                $image = time().'_'.rand(0,99999999).'.'.$extension;
                $file->move(public_path('images/products'), $image); // uploaded it at folder
                foreach($photos_sizes_colors as $item){
                    $colors = $item->color;
                    $sizes = implode(',',$item->sizes);
                    // if update then update old sizes
                    // this is because if i have  1xl , 2xl
                    // then updated it to 1xl , 2xl , 3xl
                    // i will make a new with new size
                    // and update previous

                    if(request()->filled('id')){
                        UpdateProductPhotoData::updateColor
                        (request('id'),$product_colors,$user_updated_colors,$colors,$sizes , $item->color_ids);
                    }
                    if(sizeof($item->photos) > 0) {
                        foreach ($item->photos as $photo) {
                            // get photo name that is uploaded
                            if ($photo == $old_name) {
                                $photo = $image;
                                products_images::query()->create([
                                    'product_id' => $product->id,
                                    'image' => $photo,
                                    'colors' => $colors,
                                    'sizes' => $sizes,
                                ]);
                            }
                        }
                    }
                }
            }
        }else{
            // no files updated
            // update only



            foreach($photos_sizes_colors as $item){
                // check if color i had is equal to user sent
                $colors = $item->color;
                $colors_ids = $item->color_ids;
                $sizes = implode(',',$item->sizes);
                $product_id = request('id');
                UpdateProductPhotoData::updateColor
                (request('id'),$product_colors,$user_updated_colors,$colors,$sizes,$colors_ids);

            }
        }
        echo json_encode(request('commercial_sale_status'));
    }

    public function delete_product(){
        $id = request('id');
        $product = products::query()->find($id);
        if($product != null){
            $product->delete();
            return messages_output::success_message(trans('keywords.deleted_success'));
        }else{
            return messages_output::error_message(trans('keywords.error_on_deleted'));
        }
    }

    public function add_delete_fav(){
        $product = products::where('id','=',request('product_id'))->first();
        // check if this product exists
        if($product != null){
            // check if user has this product in it's favourite
            $fav_user = favourites::where('user_id','=',auth()->user()->id)
                ->where('product_id','=',$product->id)->first();
            if($fav_user == null){
                // user has not this product in it's favourite
                favourites::create([
                    'user_id'=>auth()->user()->id,
                    'product_id'=>request('product_id')
                ]);
                $data = [
                    'status'=>1,
                    'icon'=>'success',
                    'msg'=> trans('keywords.added_to_fav'),
                ];
            }else{
                // user has this product in it's favourite
                $fav_user->delete();
                $data = [
                    'status'=>1,
                    'icon'=>'success',
                    'msg'=> trans('keywords.removed_from_fav'),
                ];
            }

        }else{
            $data = [
                'status'=>0,
                'icon'=>'error',
                'msg'=> 'لم يتم اضافه المنتج الي المفضله بنجاح'
            ];
        }
        return response()->json($data);
    }

    public function all_fav(){
        return messages_output::success_message(user_favourites::my_favs(auth()->user()->id));
    }

    public function search(){
        $value = request('value');
        $output = products::selection()
            ->where('approval', '=', 1)
            ->where('status', '=', 1)
            ->whereRaw('(ar_name LIKE "%'.$value.'%" OR en_name LIKE "%'.$value.'%")')
            ->with(['product_images','user','rate'=>function($e){
                $e->with('user');
            }])
            ->addSelect([
                'fav'=>favourites::query()->whereColumn('products.id','favourites.product_id')
                    ->where('favourites.user_id','=',auth()->user()->id)
                    ->select('product_id')->latest()->limit(1)
            ])
            ->when(request()->filled('cat_id'),function($e){
                $e->where('category_id',request('cat_id'));
            })
            ->get();
        return messages_output::success_message($output);
    }

}
