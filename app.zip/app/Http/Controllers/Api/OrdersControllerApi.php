<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\classes\users\RateOrder;
use App\Http\Controllers\classes\users\user_orders;
use App\Http\Controllers\classes\users\user_rates;
use App\Http\Controllers\Controller;
use App\Http\quick_helpers\messages_output;
use Illuminate\Http\Request;

class OrdersControllerApi extends Controller
{
    //
    public function index(){
        return messages_output::success_message(
            user_orders::my_orders(auth()->user()->id , request('order_status') ?? '')
        );
    }

    public function my_rates(){
        return messages_output::success_message(user_rates::my_rates(auth()->user()->id));
    }

    public function rate_product(){
        $data = request()->all();
        $data['user_id'] = auth()->user()->id;
        RateOrder::rate_product($data);
        return messages_output::success_message(trans('keywords.rate_success'));
    }
}
