<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\classes\chat\send_message;
use App\Http\Controllers\classes\chat\un_seen_messages;
use App\Http\Controllers\Controller;
use App\Http\quick_helpers\messages_output;
use App\Models\contactings;
use Illuminate\Http\Request;


class ChatControllerApi extends Controller
{
    //
    public function unseenmessages(){
        return messages_output::success_message(un_seen_messages::un_seen_number());
    }

    public function allmessages(){
        $chats = contactings::my_inbox()->get()->groupBy('type');
        return messages_output::success_message($chats);
    }

    public function sendmessages(){
        return messages_output::success_message(send_message::send(request())->original['success']);
    }
}
