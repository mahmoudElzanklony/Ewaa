<?php


namespace App\Http\Controllers\classes\categories;


use App\Http\quick_helpers\messages_output;
use App\Models\categories;
use function App\Http\Controllers\request;

class FindCategory
{
    public static function search($name , $search){
        if($name == 'main'){
            // this is main categories page
            $output = categories::selection()
                ->where('parent_id','=',null)
                ->whereRaw('(ar_name LIKE "%'.$search.'%" OR en_name LIKE "%'.$search.'%") ')
                ->get();
        }else{
            // this is sub category
            $output = categories::
            where('parent_id','=',$name)
                ->where('ar_name','!=','اعلانات')
                ->whereRaw('(ar_name LIKE "%'.$search.'%" OR en_name LIKE "%'.$search.'%") ')
                ->get();
        }
        return  messages_output::success_message($output);
    }

    public static function tree_cats($branches , &$cats_ids){
        foreach ($branches as $branch){
            array_push($cats_ids,$branch->id);
            $sub_cats = categories::query()
                ->with('children')
                ->where('parent_id','=',$branch->id)
                ->get();
            if(sizeof($branch->children) > 0){
                self::tree_cats($sub_cats,$cats_ids);
            }
        }
    }
}
