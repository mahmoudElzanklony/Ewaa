<?php


namespace App\Http\Controllers\classes\checkout;
use App\Http\traits\lang_keywords;

class KeyWordsData
{
    use lang_keywords;
    public function checkout_words(){
        return $this->get_keywords(['payment_type','pay_on_received','client_data','username','phone','address','info',
            'total_price','enter_promo_code','points',
            'payment_online',
            'use_my_points','i_have_promo_code','number_of_pieces',
            'select_government','select_city','select_center','order_address',
            'card_info','card_number','card_end','buy','total_after_coupon','pay_using_points'
        ]);
    }
}
