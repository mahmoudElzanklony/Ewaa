<?php


namespace App\Http\Controllers\classes\checkout;


use App\Http\quick_helpers\messages_output;
use App\Models\users_promo_codes;

class validatePromoCode
{
    public static function validatePromo($number){
        $user_promo_code = users_promo_codes::query()->with('promo')->whereHas('promo',function ($q) use ($number){
            $q->where('number','=',$number);
        })->first();
        if($user_promo_code != null){
            // check date
            if($user_promo_code->promo->end_date >= date('Y-m-d')){
                $amount = $user_promo_code->promo->how_much;
                return messages_output::success_message(['message'=>trans('keywords.activatedpromocode').$amount,
                                                        'amount'=>$amount,
                                                        'coupon_id'=>$user_promo_code->promo->id,
                                                        'promo_code_ar_name'=>$user_promo_code->promo->ar_name,
                                                        'promo_code_en_name'=>$user_promo_code->promo->en_name]);
            }else{
                return messages_output::error_message(trans('keywords.invalidpromodate'));
            }

        }else{
            return messages_output::error_message(trans('keywords.invalidpromo'));
        }
    }
}
