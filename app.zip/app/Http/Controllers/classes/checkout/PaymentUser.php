<?php


namespace App\Http\Controllers\classes\checkout;


use App\Http\Controllers\classes\users\user_points;
use App\Models\notifications;
use App\Models\order_piece_data;
use App\Models\orders;
use App\Models\orders_promo_code;
use App\Models\packages;
use App\Models\products;
use App\Models\sellers_packages;
use App\Models\User;
use App\Models\users_points;
use App\Models\users_promo_codes;

class PaymentUser
{
    public static function cash_payment($request , $products){
        if($request->has('coupon')){
            $coupon_data = validatePromoCode::validatePromo($request->get('coupon'));
            if(isset($coupon_data->original['success'])){
                $amount = $coupon_data->original['success']['amount'];
            }else{
                $amount = 0;
            }
        }else{
            $amount = 0;
        }
        if($request->has('payment')){
            if($request->get('payment') == 'cach' || $request->get('payment') == 'points'){
                // check this products not null

                if($products != null){
                    foreach($products as $item){
                        // check if product order is piece or three
                        // check in_stock is big or equal pieces
                        $product = products::query()->with('three_info')
                            ->where('id', '=', $item->product->id)->first();

                        if(
                            ($item->order_type == 'piece' && $product->in_stock >= $item->pieces)
                            ||
                            ($item->order_type == 'three' && $product->three_info->in_stock >= $item->pieces)
                        ) {
                            // make a new order
                            $order = orders::create([
                                'user_id' => auth()->user()->id,
                                'product_id' => $item->product->id,
                                'client_name' => $request->get('client_name'),
                                'address' => $request->get('address'),
                                'center_id' => $request->get('center_id'),
                                'pieces' => $item->pieces,
                                'order_type'=>$item->order_type,
                                'price' => $item->total_price - $amount,
                                'payment_type' => $request->get('payment'),
                                'order_status' => 'معلق',
                                'seller_profit_status' => 0,
                            ]);
                            // check if promo code is > 0
                            if($amount > 0){
                                // create order promo code
                                orders_promo_code::query()->create([
                                    'order_id'=>$order->id,
                                    'promo_code_ar_name'=>$coupon_data->original['success']['promo_code_ar_name'],
                                    'promo_code_en_name'=>$coupon_data->original['success']['promo_code_en_name'],
                                    'old_price'=>$item->total_price,
                                    'new_price'=>$item->total_price - $amount,
                                ]);
                                // delete this promo code from user
                                $coupon_id = $coupon_data->original['success']['coupon_id'];
                                $user_copon_data = users_promo_codes::query()
                                    ->where('user_id','=',auth()->id())
                                    ->where('promo_code_id','=',$coupon_id)->first();
                                if($user_copon_data != null){
                                    if($user_copon_data->pieces > 1) {
                                        $user_copon_data->pieces = $user_copon_data->pieces - 1;
                                        $user_copon_data->save();
                                    }else{
                                        $user_copon_data->delete();
                                    }
                                }
                            }
                            // reset amount promo code to zero
                            $amount = 0;

                            $order_info = order_piece_data::query()->create([
                                'order_id'=>$order->id,
                                'color'=>$item->order_type == 'piece' ? $item->color:'',
                                'size'=>$item->order_type == 'piece' ?implode(',',$item->sizes):'',
                                'info'=>$item->info ?? '',
                            ]);
                            // remove from product stock number of pieces client buy

                            if($item->order_type == 'piece') {
                                $product->in_stock = $product->in_stock - $item->pieces;
                            }else{
                                // remove from stock of three
                                $product->three_info->in_stock = $product->three_info->in_stock - $item->pieces;
                            }
                            $product->save();


                            // get number of orders that seller make

                            $seller_id = products::where('id', '=', $item->product->id)->first()->user_id;

                            $orders_no = orders::whereHas('product', function ($q) use ($seller_id) {
                                $q->where('user_id', '=', $seller_id);
                            })->count();

                            $seller_pack = sellers_packages::query()
                                ->where('user_id', '=', $seller_id
                                )->first();

                            $seller_now_pack_info = sellers_packages::where('user_id', '=', $seller_id)->first();

                            // get a package that should go to
                            $package = packages::selection()->where('no_orders','=',$orders_no)->first();
                            if($package != null){
                                // i should go to
                                // check if admin control for this user package or not
                                if ($seller_now_pack_info->admin_control == 0) {
                                    // in this case not control
                                    $seller_now_pack_info->package_id = $package->id;
                                    $seller_now_pack_info->save();
                                    notifications::create([
                                        'sender_id' => User::where('type', '=', 'admin')->first()->id,
                                        'receiver_id' => $seller_id,
                                        'info' => trans('keywords.package_level_up').' '. $package->name,
                                        'url' => '/profile',
                                        'seen' => 0,
                                    ]);
                                }
                            }

                            // send notification to seller
                            notifications::create([
                                'sender_id' => auth()->user()->id,
                                'receiver_id' => $item->product->user_id,
                                'info' => trans('keywords.client_buy') . $item->pieces . ' '.trans('keywords.from').' ' . $item->product->name,
                                'url' => '/profile',
                                'seen' => 0,
                            ]);
                            // send notification to admin
                            notifications::create([
                                'sender_id' => auth()->user()->id,
                                'receiver_id' => User::where('type', '=', 'admin')->first()->id,
                                'info' => $request->get('client_name') . trans('keywords.buy') . $item->pieces .' '. trans('keywords.from').' '. $item->product->name,
                                'url' => 'dashboard/orders',
                                'seen' => 0
                            ]);

                            // if i pay with points
                            if($request->get('payment') == 'points'){
                                $user_points_data = users_points::query()
                                    ->where('user_id','=',auth()->user()->id)->first();
                                $user_points_data->points = $user_points_data->points - $item->product->price_in_points;
                                $user_points_data->save();
                            }


                            $status = 1;
                        }else{
                            $status = 0;
                        }
                    }
                    session()->forget('products');

                }
            }else{
                // visa or master card
            }

        }else{
            $status = 0;
        }
        return $status;
    }
}
