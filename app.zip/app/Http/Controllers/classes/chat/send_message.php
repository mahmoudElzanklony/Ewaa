<?php


namespace App\Http\Controllers\classes\chat;


use App\Http\quick_helpers\messages_output;
use App\Models\contactings;
use App\Models\notifications;
use App\Models\User;

class send_message
{
    public static function send(){
        if(request('message') != '') {
            // check type
            $types = ['problem_in_order','problem_in_delivery','problem_in_recovery',
                'problem_in_payment','problem_in_product','problem_in_account'];

            if(request()->filled('admin_status')){
                // admin
                $receiver_id = request('receiver_id');
                // send notification
                notifications::query()->create([
                   'sender_id'=>auth()->user()->id,
                   'receiver_id'=> request('receiver_id'),
                   'info'=>'هناك رساله جديده في صندوق الوارد الخاص بك',
                   'url'=>'/profile?support-type=',
                   'seen'=>0
                ]);
            }else{
                $receiver_id = User::query()->where('type', '=', 'admin')->first()->id;
            }

            if(request()->filled('type') && in_array(request('type'),$types)) {
                $item = contactings::query()->create([
                    'sender_id' => auth()->user()->id,
                    'receiver_id' => $receiver_id,
                    'message' => request('message'),
                    'type' => request('type'),
                    'seen'=>0
                ]);
                return messages_output::success_message($item);
            }else{
                return messages_output::error_message(trans('keywords.type_incorrect'));
            }
        }else{
            return messages_output::error_message(trans('keywords.empty_message'));
        }
    }
}
