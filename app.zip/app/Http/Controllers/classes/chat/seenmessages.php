<?php


namespace App\Http\Controllers\classes\chat;
use App\Models\contactings;
use App\Models\User;

class seenmessages
{
    public static function seen($receiver_id,$type){
        $unseen = contactings::query()
            ->where('receiver_id','=',$receiver_id)
            ->where('seen','=',0)
            ->where('type','=',$type)->get();

        foreach($unseen as $un){
            $un->seen = 1;
            $un->save();
        }
        return sizeof($unseen);
    }

    public static function seenDashbaord($sender_id,$type){
        $unseen = contactings::query()
            ->whereRaw(" sender_id = ".$sender_id." AND
receiver_id in (SELECT id FROM users WHERE type = 'admin')")
            ->where('seen','=',0)
            ->where('type','=',$type)->get();

        foreach($unseen as $un){
            $un->seen = 1;
            $un->save();
        }
        return sizeof($unseen);
    }
}
