<?php


namespace App\Http\Controllers\classes\chat;


use App\Models\contactings;

class un_seen_messages
{
    public static function un_seen_number(){
        return collect(contactings::my_unseen_data(auth()->user()->id))->map(function($e){
            return [$e->type => $e->sum_inbox];
        });
    }
}
