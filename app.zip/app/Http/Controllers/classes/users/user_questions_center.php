<?php


namespace App\Http\Controllers\classes\users;


class user_questions_center
{
    public static function questions_center(){
        return [
          'problem_in_order'=>[trans('keywords.problem_in_order'),'note.png'],
          'problem_in_delivery'=>[trans('keywords.problem_in_delivery'),'delivery.png'],
          'problem_in_recovery'=>[trans('keywords.problem_in_recovery'),'return_product.png'],
          'problem_in_payment'=>[trans('keywords.problem_in_payment'),'pay.png'],
          'problem_in_product'=>[trans('keywords.problem_in_product'),'product.png'],
          'problem_in_account'=>[trans('keywords.problem_in_account'),'user.png'],
        ];
    }
}
