<?php


namespace App\Http\Controllers\classes\users;


use App\Models\favourites;

class user_favourites
{
    public static function my_favs($user_id){
        return  favourites::query()->where('user_id','=',$user_id)
            ->with(['product'=>function($q){
                $q->select('id',app()->getLocale().'_name as name' ,app()->getLocale().'_info as info' ,'price','in_stock',
                'category_id'
                ,'discount','start_discount_date','end_discount_date','status')
                    ->with('product_first_image','product_images')
                ->addSelect([
                    'fav'=>favourites::query()->whereColumn('products.id','favourites.product_id')
                        ->where('favourites.user_id','=',auth()->user()->id)
                        ->select('product_id')->latest()->limit(1)
                ]);
            }])->get();
    }
}
