<?php


namespace App\Http\Controllers\classes\users;


use App\Http\quick_helpers\save_image_file;
use App\Models\sellers_packages;

class save_seller_package_info
{

    public static function save_seller_package_data($request)
    {
        $data = $request->validate([
            'user_id'=>'required|exists:users,id',
            'package_id'=>'required|exists:packages,id',
            'admin_control'=>'required',
            'store_name'=>'required|max:191',
            'store_address'=>'required|max:191',
            'store_image'=>'file|required',
        ]);
        $image = save_image_file::save_image($data['store_image'],'seller_info');
        if(is_string($image)) {
            $data['store_image'] = $image;
            $info = sellers_packages::query()->updateOrCreate([
                'id' => $request->has('id') ? $request('id') : null
            ], $data);
            return $info;
        }else{
            return $image;
        }

    }
}
