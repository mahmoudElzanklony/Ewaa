<?php


namespace App\Http\Controllers\classes\users;


use App\Models\orders;

class user_points
{
    public static function my_points($user_id){
        return orders::where('user_id','=',$user_id)
            ->with(['order_piece_data','orders_promo_code','product'=>function($query){
                $query->select('id','user_id','category_id',
                    app()->getLocale().'_name as name',app()->getLocale().'_info as info',
                    'guide',
                    'price','in_stock','price_in_points','points','discount',
                    'start_discount_date','end_discount_date',
                    'status','approval')->with('product_first_image','category')
                    ->with(['product_first_image','category','rate'])->with(['product_first_image','category'=>function($e){
                        $e->select('id',app()->getLocale().'_name as name',app()->getLocale().'_info as info');
                    }]);
            },'rate'=>function($q) use ($user_id){
                $q->where('user_id','=',$user_id);
            }])->get();
    }
}
