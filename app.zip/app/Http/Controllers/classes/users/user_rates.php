<?php


namespace App\Http\Controllers\classes\users;


use App\Models\favourites;
use App\Models\rates;

class user_rates
{
    public static function my_rates($user_id){
        return rates::where('user_id','=',$user_id)->with(['order'=>function($q){
            $q->with(['product'=>function($query){
                $query->with(['user','product_first_image'])
                ->addSelect([
                    'fav'=>favourites::query()->whereColumn('products.id','favourites.product_id')
                        ->where('favourites.user_id','=',auth()->user()->id)
                        ->select('product_id')->latest()->limit(1)
                ]);
            }]);
        }])->get();
    }
}
