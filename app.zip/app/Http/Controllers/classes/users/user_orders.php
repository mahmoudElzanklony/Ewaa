<?php


namespace App\Http\Controllers\classes\users;


use App\Models\favourites;
use App\Models\orders;

class user_orders
{
    public static function my_orders($user_id , $status = ""){
        return orders::query()->where('user_id','=',$user_id)
            ->with(['product'=>function($query){
                $query->select('id','user_id','category_id',
                    app()->getLocale().'_name as name',app()->getLocale().'_info as info',
                    'guide',
                    'price','in_stock','price_in_points','points','discount',
                    'start_discount_date','end_discount_date',
                    'status','approval')->with('product_first_image','category')
                    ->with(['product_first_image','category','rate','product_images'])
                    ->addSelect([
                        'fav'=>favourites::query()->whereColumn('products.id','favourites.product_id')
                            ->where('favourites.user_id','=',auth()->user()->id)
                            ->select('product_id')->latest()->limit(1)
                    ]);
            },'orders_promo_code','order_piece_data'])
            ->when($status != "",function ($e) use ($status){
                $e->where('order_status',$status);
            })
            ->get();
    }
}
