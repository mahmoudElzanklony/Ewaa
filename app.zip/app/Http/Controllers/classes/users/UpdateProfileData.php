<?php


namespace App\Http\Controllers\classes\users;


use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UpdateProfileData
{
    public static function updateData($req,$request){
        $validated = $req->validated();
        if(request()->filled('password')){
            $validated['password'] = bcrypt(request('password'));
        }
        if($request->hasFile('image')){
            $file = $request->file('image');
            $extension = $file->extension();
            $image = 'image.'. date('y-m-d'). time().'.'.$extension;
            $file->move(public_path('images/users'), $image);
            $validated['image'] = $image;
        }
        User::where('id','=',auth()->user()->id)->update($validated);

        return json_encode(User::where('id','=',auth()->user()->id)->first());
    }
}
