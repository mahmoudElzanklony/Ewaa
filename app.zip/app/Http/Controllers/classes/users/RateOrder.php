<?php


namespace App\Http\Controllers\classes\users;


use App\Models\orders;
use App\Models\rates;

class RateOrder
{
    public static function rate_product($data){
        rates::create($data);
        $points = user_points::my_points(auth()->user()->id);
        return $points;
    }
}
