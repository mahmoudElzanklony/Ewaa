<?php


namespace App\Http\Controllers\classes\products;


use App\Models\products;
use App\Models\rates;

class AllInfoAboutProduct
{
    public static function all_info_product($id){
        $product_info = products::selection()->with(['user','product_images','three_info'=>function($query){
            $query->select('id','product_id',
                app()->getLocale().'_info as info',
                'price','in_stock','discount','start_discount_date_three','end_discount_date_three');
        },'category'=>function($e){
            $e->select('id',app()->getLocale().'_name as name');
        },'comments'=>function($q){
            $q->with('user')->orderBy('id','DESC');
        }])->where([
            ['id','=',$id]
        ])->first();
        return $product_info;
    }

    public static function rate_about_product($product_id){
        return rates::with(['user','order'])->whereHas('order',function($q) use ($product_id){
            $q->where('product_id','=',$product_id);
        })->get();
    }
}
