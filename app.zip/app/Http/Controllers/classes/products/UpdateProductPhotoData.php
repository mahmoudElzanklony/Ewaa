<?php


namespace App\Http\Controllers\classes\products;


use App\Models\products_images;

class UpdateProductPhotoData
{
    public static function updateSizes($id,$colors,$sizes){
        $products_photos = products_images::query()
            ->where('product_id',$id)
            ->where('colors','=',$colors)
            ->get();
        // user doesnt change color
        foreach($products_photos as $pro){
            $pro->sizes = $sizes;
            $pro->save();
        }
    }


    public static function updateColor($id,&$product_colors,$user_updated_colors,$colors,$sizes , $colors_ids = []){

        // check if not empty colors_ids
        // update
        if(sizeof($colors_ids) > 0){
            $products_photos = products_images::query()
                ->where('product_id',$id)
                ->whereIn('id',$colors_ids)
                ->get();
            foreach($products_photos as $pro){
                $pro->sizes = $sizes;
                $pro->colors = $colors;
                $pro->save();
            }
        }

    }
}
