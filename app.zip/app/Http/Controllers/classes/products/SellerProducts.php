<?php


namespace App\Http\Controllers\classes\products;


use App\Models\favourites;
use App\Models\orders;
use App\Models\products;

class SellerProducts
{
    public static function myproducts($seller_id)
    {

        return  products::selection()
            ->where('user_id','=',$seller_id)
            ->with(['product_first_image','category','rate','product_images'])
            ->addSelect([
                'fav'=>favourites::query()->whereColumn('products.id','favourites.product_id')
                    ->where('favourites.user_id','=',auth()->user()->id)
                    ->select('product_id')->latest()->limit(1)
            ])->orderBy('id','DESC')
            ->get();

    }

    public static function activeProducts($seller_id){
        return products::selection()->where('user_id','=',$seller_id)
            ->where('status','=',1)->count();
    }

    public static function orders_products($seller_id){
        return orders::with(['order_piece_data','orders_promo_code','product'=>function($q){
            $q->select('id','user_id','category_id',
                app()->getLocale().'_name as name',app()->getLocale().'_info as info',
                'guide',
                'price','in_stock','price_in_points','points','discount',
                'start_discount_date','end_discount_date',
                'status','approval')->with('category',function($e){
                    $e->select('id',app()->getLocale().'_name as name',
                        app()->getLocale().'_info as info','image','cover','parent_id','profit_percentage');
            })
                ->addSelect([
                    'fav'=>favourites::query()->whereColumn('products.id','favourites.product_id')
                        ->where('favourites.user_id','=',auth()->user()->id)
                        ->select('product_id')->latest()->limit(1)
                ]);
        },'client_answer'=>function($q){
            $q->with(['product_answer'=>function($q){
                $q->with('question');
            }]);
        },'rate'=>function($e){
            $e->with('user');
        }])->whereHas('product',function($q) use ($seller_id){
            $q->where('products.user_id','=',$seller_id);
        })->get();
    }
}
