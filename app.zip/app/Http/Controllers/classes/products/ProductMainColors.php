<?php


namespace App\Http\Controllers\classes\products;


use App\Models\products;
use function App\Http\Controllers\request;

class ProductMainColors
{
    public static function my_colors($id){
        $product_photos =  products::query()->where('id','=',$id)
            ->with('product_images')->first()
            ->product_images->groupBy('colors')
            ->map(function ($e){});
        $product_colors = [];
        foreach($product_photos as $key =>$val){
            array_push($product_colors,$key);
        }
        return $product_colors;
    }
}
