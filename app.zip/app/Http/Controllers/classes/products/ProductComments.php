<?php


namespace App\Http\Controllers\classes\products;


use App\Models\comments;
use App\Models\notifications;
use App\Models\products;
use App\Models\User;

class ProductComments
{
    public static function deleteComment($comment_id){
        $comment = comments::where('id','=',$comment_id)->first();
        if($comment){
            if($comment->user_id == auth()->user()->id){
                $comment->delete();
                $status = 1;
            }else{
                $status = 0;
            }
        }else{
            $status = 0;
        }
        return $status;
    }

    public static function insertComment($product_id,$comment , $web = true , $id = false){
        if(auth()->check()){
            if($product_id && $comment){
                $product_owner = products::where('id','=',$product_id)->first();
                if($product_owner != null){
                    // make comment
                    $comment_data =  comments::query()->updateOrCreate([
                        'id'=>$id != false ? $id : null
                    ],[
                        'user_id'=>auth()->user()->id,
                        'product_id'=>$product_id,
                        'comment'=>$comment,
                        'parent_id'=>0,
                    ]);
                    // send notification to product owner
                    // check if sender notification has user name
                    if(auth()->user()->username == ""){
                        $username = 'عميل';
                    }else{
                        $username = auth()->user()->username;
                    }
                    $admin = User::where('type','=','admin')->first();
                    // check if user make comment not admin
                    if(auth()->user()->type != 'admin') {
                        notifications::create([
                            'sender_id' => auth()->user()->id,
                            'receiver_id' => $admin->id,
                            'info' =>   $username . trans('keywords.comment_on') . $product_owner->name,
                            'url' => '/products/' . $product_owner->category_id . '/details/' . $product_id,
                            'seen' => 0
                        ]);
                    }else{
                        // admin now make comment for product
                        // so get all users they make comment for this product
                        $users = comments::where('product_id','=',$product_id)->with('user')->get();
                        if($users != null){
                            foreach ($users as $user){
                                if($user->user->type == 'client') {
                                    notifications::create([
                                        'sender_id' => $admin->id,
                                        'receiver_id' => $user->user_id,
                                        'info' => trans('keywords.admin_make_comment') . $product_owner->name,
                                        'url' => '/products/' . $product_owner->category_id . '/details/' . $product_id,
                                        'seen' => 0
                                    ]);
                                }
                            }
                        }
                    }
                    $status = 1;
                    if($web == false){
                        $ouput = comments::query()->where('product_id','=',$product_id)->get();
                    }else {
                        $ouput = '<div class="rate">
                    <div class="image">
                        <img src="/images/users/' . auth()->user()->image . '">
                    </div>
                    <div class="info">
                        <p style="padding-left:25px">
                                <span>' . $comment . '</span>
                                <span><i class="ri-close-fill" id=' . $comment_data->id . '></i></span>
                        </p>
                    </div>
                </div>';
                    }
                    $result = [
                        'status'=>$status,
                        'ouput' => $ouput
                    ];
                }else{
                    $status = 0;
                    $result = [
                        'status'=>$status,
                        'ouput' => '',
                    ];
                }


            }else{
                $status = 0;
                $result = [
                    'status'=>$status,
                    'ouput' => '',
                ];
            }

        }else{
            $status = 0;
            $result = [
                'status'=>$status,
                'ouput' => '',
            ];
        }
        return $result;
    }
}
