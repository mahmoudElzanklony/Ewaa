<?php


namespace App\Http\Controllers\classes\products;


use App\Http\quick_helpers\messages_output;
use App\Models\favourites;
use App\Models\products;
use function App\Http\Controllers\request;

class FindProducts
{
    public static function search($data){
        // if order is found
        $q = products::selection()
            ->with(['product_first_image','product_answers'=>function($e){
                $e->with('question');
            },'product_images'=>function($e){
                $e->select('product_id','colors','sizes');
                //->groupBy('colors');
            }])
            ->addSelect([
            'fav'=>favourites::query()->whereColumn('products.id','favourites.product_id')
                ->where('user_id',auth()->check() == 1 ? auth()->id():0)
                ->latest()
                ->limit(1)
                ->select('product_id'),
        ]);
        if($data['category'] != ''){
            if(is_array($data['category'])){
                $q->with('product_first_image')
                    ->whereIn('category_id',$data['category']);
            }else if($data['category'] == "discount"){
                $q->with('product_first_image')
                    ->where('discount','>',0);
            }
        }

        if(in_array('product_name',array_keys($data))){
            $q->where(app()->getLocale().'_name','LIKE','%'.$data['product_name'].'%');
        }

        if(in_array('order',array_keys($data))){
            // if category is number
            if(is_array($data['category'])){
                $q->orderBy('id',$data['order']);
            }else if($data['category'] == "discount"){
                $q->orderBy('id',$data['order']);
            }else{
                $q->with('product_first_image')
                    ->orderBy('id',$data['order']);
            }
        }

        if(in_array('min_price',array_keys($data)) && in_array('max_price',array_keys($data))){
            if($data['min_price'] != null && $data['max_price'] != null) {
                // if category is number
                if (is_array($data['category'])) {
                    $q->whereRaw('(price -  price  * discount / 100)  between ' . $data['min_price'] . ' AND ' . $data['max_price'] . ' ',)
                        ->whereIn('category_id', $data['category']);
                } else if ($data['category'] == "discount") {
                    $q->whereRaw('(price -  price  * discount / 100)  between ' . $data['min_price'] . ' AND ' . $data['max_price'] . ' ',)
                        ->where('discount', '>', 0);
                } else {
                    $q->with('product_first_image')
                        ->whereBetween('price', array($data['min_price'], $data['max_price']));
                }
            }
        }

        if(in_array('rate',array_keys($data))){
            $rates = $data['rate'];
            if($data['category'] == 'discount') {
                $q->with(['orders.rate'])
                    ->whereHas("orders.rate", function ($query) use ($rates) {
                        $query->whereIn("star", $rates);
                    });
            }else{
                $q->with(['orders.rate'])
                    ->whereHas("orders.rate", function ($query) use ($rates) {
                        $query->whereIn("star", $rates);
                    })->whereIn('category_id',$data['category']);
            }
        }
        $q->where('approval','=',1)
            ->where('status','=',1);

        return messages_output::success_message($q->paginate(9));

    }
}
