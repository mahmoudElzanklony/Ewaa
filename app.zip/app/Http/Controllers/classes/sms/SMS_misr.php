<?php


namespace App\Http\Controllers\classes\sms;


class SMS_misr
{
    public static function send($data){
        $endpoint = "https://smssmartegypt.com/sms/api/?username=mahmoud_elzanklony@yahoo.com&password=zanklony202017&sendername=First Meet&mobiles=2".$data['phone']."&message=".urlencode($data['sms'])."&Content-Type=application/json;charset=utf-8";
        $client = new \GuzzleHttp\Client();


        $response = $client->request('GET', $endpoint);
        $statusCode = $response->getStatusCode();
        $content = json_decode($response->getBody(), true);
    }
}
