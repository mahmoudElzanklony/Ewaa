<?php

namespace App\Http\Controllers;

use App\Http\Controllers\classes\categories\FindCategory;
use App\Http\Controllers\classes\products\AllInfoAboutProduct;
use App\Http\Controllers\classes\products\FindProducts;
use App\Http\Controllers\keywords_lang\ProductDetailsKeywords;
use App\Models\categories;
use App\Models\favourites;
use App\Models\orders;
use App\Models\products;
use App\Models\products_answers;
use App\Models\rates;
use Illuminate\Http\Request;
use Illuminate\Routing\Route;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Inertia\Inertia;
use App\Http\traits\lang_keywords;
class ProductsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    use lang_keywords;
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */


    public function paginateProducts(){

        if(request('category') != null) {
            $products = products::selection()->with('product_first_image')
                ->whereIn('category_id',  request('category'))
                ->where('approval', '=', 1)
                ->where('status', '=', 1)
                ->orderBy('id','DESC')
                ->paginate(1);
        }
        return response()->json($products);
    }

    public function display($id , $name){
        //
        $branches = categories::cat_branches($id)->with('children')
            ->get();
        $cats_ids = [];

        if(sizeof($cats_ids) == 0){
            $cats_ids = [$id];
        }

        FindCategory::tree_cats($branches , $cats_ids);


        $name = str_replace('-',' ',$name);
        $cat = categories::selection()->where('id','=',$id)->with('parent',function ($e){
            $e->select('id',app()->getLocale().'_name as name',app()->getLocale().'_info as info','cover');
        })->first();
        $keywords = '';
        $last_products =  products::where('category_id','=',$id)
            ->select(app()->getLocale().'_name as name')
            ->limit(15)->orderBy('id','DESC')->get();
        $branches_cats = categories::query()->where('parent_id','=',$cat->id)
            ->select('id',app()->getLocale().'_name as name')->get();
        foreach($last_products as $p){
            $keywords .= $p->name.' , ';
        }
        if($cat != null) {
            $title = 'منتجات قسم '.$cat->name;

            $keywords_data = $this->get_keywords(['website_name','website_categories','home','categories',
                'offers','explore_products','input_search',
                'inner_categories','search_about_product','show_products','from_newest_to_oldest',
                'from_oldest_to_newest','price_category','lowest_value','highest_value','rates',
                'see_more','add_to_cart','arrow_direction','no_discount','no_items','buy','add','to_cart',
                'close','product_not_available',
                'product_name','category','price','client_rate','order_status','info_about_request','admin_profit',
                'my_profit','profit_status','not_yet_rated','see_info',
                'pending','it_was_received','filter_products'
            ]);

            return Inertia::render('products', [
                'cat'=>$cat,
                'oneway'=>true,
                'categories_search'=>$cats_ids,
                'head_data'=>['title'=>$title,'description'=>$cat->info,'keywords'=>$keywords],
                'branches_cats'=>$branches_cats,
                'keywords'=>$keywords_data,
            ]);
        }else{
            return redirect('/categories');
        }
    }

    public function show($id)
    {
        //
        $cat = categories::where('id','=',$id)->with('parent')->first();
        $keywords = '';
        $last_products =  products::where('category_id','=',$id)->select('name')->limit(15)->orderBy('id','DESC')->get();
        foreach($last_products as $p){
            $keywords .= $p->name.' , ';
        }
        if($cat != null) {
            $title = 'منتجات قسم '.$cat->name;
            return Inertia::render('products', [
                'cat'=>$cat,
                'oneway'=>true,
                'categories_search'=>[$id],
                'head_data'=>['title'=>$title,'description'=>$cat->info,'keywords'=>$keywords],
            ]);
        }else{
            return redirect('/categories');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function info_questions($product){
        $info_questions =  products_answers::with('question')->get()
            ->where('product_id','=',$product->id)->groupBy('question_id');

        return $info_questions;
    }

    public function infoquestions(){
        $product = products::where('id','=',request('product_id'))->first();
        $info_questions = $this->info_questions($product);
        echo json_encode($info_questions);
    }

    public function productdetails(categories $category , products $product , $name = ""){
        if($product->status == 0){
            return back()->with('message',trans('keywords.hide_product'));
        }
        if($product->approval == 0){
            return back()->with('message',trans('keywords.not_accepted_product'));
        }
        $product_info = AllInfoAboutProduct::all_info_product($product->id);

        $rates = AllInfoAboutProduct::rate_about_product($product->id);

        // check if product status is 1
        $cat_check = $product->category_id;
        $back_status = 0;
        while($cat_check != null){
            $parent = categories::query()->where('id','=',$cat_check)->first();
            if($parent->status == 0){
                $back_status = 1;
                break;
            }
            $cat_check = $parent->parent_id;
        }
        if($back_status == 1){
            return back();
        }

        $seller_id = products::where('id','=',$product->id)->first()->user_id;
        $sold = orders::whereHas('product',function($query) use ($seller_id){
            $query->where('user_id','=',$seller_id);
        })->count();

        $number_products_posts = products::where('user_id','=',$seller_id)->count();
        $avg_rate_products = rates::with('order')->whereHas('order',function($q) use ($seller_id){
            $q->with('product')->whereHas('product',function($query) use ($seller_id){
                $query->where('user_id','=',$seller_id);
            });
        })->avg('rates.star');

        $seller_info = [
            'sold'=>$sold,
            'number_products_posts'=>$number_products_posts,
            'avg_rate_products'=>$avg_rate_products,
        ];
        $title = 'بنكسي | تفاصيل منتج '.$product_info->name;
        $keywords = new ProductDetailsKeywords();
        return Inertia::render('productdetails',[
            'product_information'=>$product_info,
            'rates'=>$rates,
            'seller_info'=>$seller_info,
            'head_data'=>['title'=>$title,'description'=>$product_info->info,'keywords'=>implode(',',explode(' ',$product_info->info))],
            'keywords'=>$keywords->my_keywords()
        ]);
    }

    public function search(){
        $value = request('value');
        $category = request('category');

        if($category == "discount"){
            $output = products::selection()->with('product_first_image')
                ->where('discount', '>', 0)
                ->where('approval','=',1)
                ->where('status','=',1)
                ->whereRaw('ar_name LIKE "%'.$value.'%" OR en_name LIKE "%'.$value.'%"')
                ->paginate(9);

        }else if(is_array($category)){
            $output = products::selection()->with('product_first_image')
              ->whereIn('category_id',  $category)
              ->where('approval','=',1)
              ->where('status','=',1)
                ->whereRaw('ar_name LIKE "%'.$value.'%" OR en_name LIKE "%'.$value.'%"')

                ->paginate(9);

        }else{
            // search navbar
            if($value == ''){
                $output = [];
            }else {
                $output = products::selection()->with('product_first_image')
                    ->where('approval', '=', 1)
                    ->where('status', '=', 1)
                    ->whereRaw('ar_name LIKE "%'.$value.'%" OR en_name LIKE "%'.$value.'%"')
                    ->get();
            }
        }
        echo  json_encode(['data'=>$output]);
    }




    public function filter(){
        // if order is found
        return FindProducts::search(request()->all());

        // echo json_encode(request()->all());
        // echo json_encode($q->where('approval','=',1)->where('status','=',1)->paginate(9));
    }


    public function discount(){
        $products = products::with('product_first_image')
            ->where('discount', '>',0)
            ->where('approval','=',1)
            ->where('status','=',1)->get();
        $cat = new categories();

        if(app()->getLocale() == 'ar') {
            $cat->name = 'خصومات';
        }else{
            $cat->name = 'discount';
        }
        if(app()->getLocale() == 'ar') {
            $cat->info = 'افضل الخصومات والعروض علي جميع المنتجات';
        }else{
            $cat->info = 'best discounts on products';
        }
        $cat->image = 'dicount.jpg';
        $cat->cover = '';
        $keywords_data = $this->get_keywords(['website_name','website_categories','home','categories',
            'offers','explore_products','input_search',
            'inner_categories','search_about_product','show_products','from_newest_to_oldest',
            'from_oldest_to_newest','price_category','lowest_value','highest_value','rates',
            'see_more','add_to_cart','arrow_direction','no_discount','no_items','buy','add','to_cart','close',
            'product_not_available'
        ]);
        return Inertia::render('products', [
            'data' => $products,
            'cat'=>$cat,
            'oneway'=>true,
            'categories_search'=>'discount',
            'keywords'=>$keywords_data,
            'head_data'=>['title'=>'بنكسي | اخر عروض ومفاجئات بنكسي ','description'=>'عروض وتخفيضات علي منتجات من بنكسي واسعار منافسه الحق اشتري قبل ما العرض يخلص','keywords'=>'عروض , تخفيضات , مفاجئات , خصومات, عروض بنكسي'],

        ]);
    }

    public function checkprocessbuy(){
        $piecesPending = 0;
        if(session()->get('products')) {
            foreach (session()->get('products') as $product) {
                if ($product['product']['id'] == request('product_id')) {
                    $piecesPending += $product['pieces'];
                }
            }
        }
        return response()->json(['data'=>$piecesPending]);
    }


}
