<?php

namespace App\Http\Controllers;
use App\Http\traits\lang_keywords;
use App\Http\Controllers\classes\chat\un_seen_messages;
use App\Http\Controllers\classes\users\user_questions_center;
use App\Http\Requests\CategoriesValidation;
use App\Models\categories;
use App\Models\categories_questions;
use App\Models\centers;
use App\Models\cities;
use App\Models\contactings;
use App\Models\features;
use App\Models\governates;
use App\Models\most_questions;
use App\Models\orders;
use App\Models\packages;
use App\Models\products;
use App\Models\products_images;
use App\Models\promo_codes;
use App\Models\sellers_packages;
use App\Models\SiteInfo;
use App\Models\User;
use App\Models\website_header;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;
use Inertia\Inertia;

class DashboardController extends Controller
{
    //
    use lang_keywords;
    public function __construct(){
        $this->middleware(function ($request, $next) {
            if(auth()->check()){
                // check if he admin
                if(auth()->user()->type == 'admin'){
                    return $next($request);
                }else if(auth()->user()->type == 'employee'){
                    return $next($request);
                }else{
                    return redirect('/login')->send();
                }
            }else{
                return redirect('/login')->send();
            }


        });

    }

    public function index(){

        $users = User::count();
        $cats = categories::count();
        $cats_questions = categories_questions::count();
        $products = products::count();
        $packages = packages::count();
        $orders = orders::count();
        $requests = contactings::query()->whereRaw('receiver_id in (select id from users where type = "admin")')->count();
        $most_questions = most_questions::count();
        $sellers_packages = sellers_packages::count();
        $employees = User::where('type','=','employee')->count();
        $governates = governates::count();
        $promo_codes = promo_codes::count();

        $data = [
            'users' => $users,
            'cats' => $cats,
            'cats_questions' => $cats_questions,
            'products' => $products,
            'packages' => $packages,
            'orders' => $orders,
            'requests' => $requests,
            'most_questions' => $most_questions,
            'sellers_packages' => $sellers_packages,
            'employees'=>$employees,
            'governates'=>$governates,
            'promo_codes'=>$promo_codes,
        ];
        return Inertia::render('dashboard/index', [
            'data' => $data
        ]);
    }


    public function users(){
        if(auth()->user()->type == 'admin') {
            $users = User::whereIn('type', ['client'])->orderBy('id','DESC')->get();
            return Inertia::render('dashboard/users', [
                'data' => $users
            ]);
        }else{
            return redirect('/');
        }
    }

    public function employees(){
        if(auth()->user()->type == 'admin') {
            $users = User::whereIn('type',['employee','writer'])->get();
            return Inertia::render('dashboard/employees', [
                'data' => $users
            ]);
        }else{
            return redirect('/');
        }
    }

    public function features(){
        $features = features::orderBy('id','DESC')->get();
        return Inertia::render('dashboard/features', [
            'data' => $features
        ]);
    }

    public function promocodes(){
        $promo_codes = promo_codes::orderBy('id','DESC')->get();
        return Inertia::render('dashboard/promocodes',[
           'data'=>$promo_codes
        ]);
    }

    public function policy(){
        return Inertia::render('dashboard/policy',[
           'content'=>SiteInfo::query()->where('name','=','policy')->first()
        ]);
    }

    public function categories(){
        if(auth()->user()->type == 'admin') {
            $cats = categories::where('parent_id', '=', null)->orderBy('id', 'DESC')->get();
            return Inertia::render('dashboard/categories', [
                'data' => $cats
            ]);
        }else{
            return redirect('/');
        }
    }

    public function checkcat(){
        $products_id = request('products_ids');
        $product_first = products::where('id','=',$products_id[0])->with('category',function($query){
            $query->with('parent');
        })->first();
        $status = true;
        foreach ($products_id as $id){
            $product = products::where('id','=',$id)->with('category',function($query){
                $query->with('parent');
            })->first();
            if($product->category->parent->id != $product_first->category->parent->id){
                $status = false;
                break;
            }
        }
        if($status == true){
            $parent_cat = categories::where('id','=',$product_first->category_id)->with('parent')->first();
            $branches = categories::where('parent_id','=',$parent_cat->parent->id)->select('id','name')->get();
        }else{
            $branches = [];
        }
        return response()->json(['branches'=>$branches,'status'=>$status]);
    }

    public function transferproductstocat(){
        foreach(request('products_ids') as $pro){
            $product = products::where('id','=',$pro)->first();
            $product->category_id = request('cat_id');
            $product->save();
        }

        return ['data'=> products::with(['product_first_image','category','user'])->where('category_id','=',request('sub'))->get()];
    }


    public function agreeproducts(){
        $cat_id = request('cat_id');
        $products = products::where('category_id','=',$cat_id)->where('approval','=',0)->get();
        foreach($products as $product){
            $product->approval = 1;
            $product->save();
        }
        $data = $output = products::with(['product_first_image','category','user'])
            ->where('category_id','=',$cat_id)->orderBy('id','DESC')->get();
        echo json_encode(['data'=>$data]);
    }

    public function switchcat(){
        $cat = categories::where('id','=',request('category_id'))->with('branches')->first();
        if(sizeof($cat->branches) == 0){
            $cat->parent_id = request('parent_id');
            $cat->save();
            $status = ['icon'=>'success','title'=>'تمت عمليه النقل بنجاح'];
        }else{
            $status = ['icon'=>'error','title'=>'هذا القسم يحتوي علي اقسام فرعيه لذلك لا يصح ان يكون قسم فرعي'];
        }
        $data = categories::where('parent_id','=',null)->orderBy('id','DESC')->get();
        return response()->json(['data'=>$data,'status'=>$status]);
    }

    public function subcats($id){
        if(auth()->user()->type == 'admin') {
            $category = categories::where('id', '=', $id)->first();
            $data = categories::where('parent_id', '=', $category->id)->orderBy('id', 'DESC')->get();
            if ($category) {
                return Inertia::render('dashboard/subcats', [
                    'category' => $category,
                    'data' => $data,
                    'parents'=>categories::where('parent_id','=',null)->get()
                ]);
            } else {
                return redirect('/dashboard');
            }
        }else{
            return redirect('/');
        }
    }

    public function checktobemaincat(){

        $cat = categories::where('id','=',request('cat_id'))->with('products')->first();
        if(request('type') == 'main') {
            if (sizeof($cat->products) > 0) {
                $status = ['icon' => 'error', 'title' => 'لا يمكن جعل هذا القسم رئيسي لانه يحتوي علي منتجات بداخله'];
            } else {
                $status = ['icon' => 'success', 'title' => 'تمت عمليه النقل ليكون قسم رئيسي بنجاح'];
                $cat->parent_id = null;
                $cat->save();
            }
        }else if(request('type') == 'sub'){
            $cat->parent_id = request('parent_id');
            $cat->save();
            $status = ['icon' => 'success', 'title' => 'تمت عمليه النقل بنجاح'];
        }
        return response()->json(
            [
                'status'=>$status,
                'data'=>categories::where('parent_id','=',request('current_cat_id'))->get()
            ]
        );

    }

    public function questions($id){
        if(auth()->user()->type == 'admin') {
            $category = categories::query()
                ->where('id', '=', $id)
                ->where('parent_id', '=', null)->first();
            if ($category) {
                $questions = categories_questions::query()
                    ->where('category_id', '=', $category->id)
                    ->orderBy('id', 'DESC')->get();
                return Inertia::render('dashboard/questions', [
                    'category' => $category,
                    'data' => ['questions'=>$questions],
                ]);
            } else {
                return redirect('/dashboard');
            }
        }else{
            return redirect('/');
        }
    }


    public function paginateproducts(){
        $products = products::with(['product_first_image','category','user'])
                    ->orderBy('id','DESC')
                    ->orderBy('id','DESC')
                    ->paginate(9);
        return response()->json($products);
    }

    public function products(){
        return Inertia::render('dashboard/products',[
            'sub'=>categories::selection()->has('products')->where('parent_id','!=',null)
                ->where('ar_name','!=','اعلانات')->get(),
            'categories'=>DB::table('categories')->where('ar_name','=','اعلانات')->get(),
            'sellers'=>User::query()->where('type','=','seller')->get()
        ]);
    }

    public function packages(){
        if(auth()->user()->type == 'admin') {
            $packages = packages::all();
            return Inertia::render('dashboard/packages', [
                'data' => $packages,
            ]);
        }else{
            return redirect('/');
        }
    }

    public function requests(){
            $un_seen = contactings::query()->selectRaw("COUNT(id) as 'no_messages' , sender_id")->whereRaw("
receiver_id in (SELECT id FROM users WHERE type = 'admin') AND seen = 0")->get();
            $no_messages_all = contactings::query()->selectRaw("COUNT(id) as 'no_messages' , sender_id")
                ->whereRaw("receiver_id in (SELECT id FROM users WHERE type = 'admin')")
                ->groupBy('sender_id')->with('user_sender')->get();
            return Inertia::render('dashboard/requests', [
                'no_messages_all' => $no_messages_all,
                'un_seen' => $un_seen,
            ]);
    }


    public function userchat(){
        if(request()->has('user_id')){
            $user = User::query()->find(request('user_id'));
            if($user != null){
                // question centers
                $user_questions_centers = user_questions_center::questions_center();

                // gey my contactings
                $contactings = contactings::query()->where('sender_id','=',request('user_id'))->get();

                // unseen inbox
                $un_seen_data_inbox =  collect(contactings::my_unseen_data_dashboard(request('user_id')))->map(function($e){
                    return [$e->type => $e->sum_inbox];
                });


                $output = [
                    'contactings'=>$contactings,
                    'user_questions_centers'=>$user_questions_centers,
                    'un_seen_data_inbox'=>$un_seen_data_inbox,
                ];
                $keywords = $this->get_keywords(['problem_in_order','problem_in_delivery','problem_in_recovery','problem_in_product',
                    'problem_in_account','problem_in_payment','questions_center','support_center'
                    ,'select_support_type','write_your_message'
                ]);
                return Inertia::render('dashboard/userchat', [
                    'output'=>$output,
                    'keywords'=>$keywords
                ]);
            }else{
                return back();
            }
        }else{
            return back();
        }
    }

    public function mostquestions(){
        $mostquestions = most_questions::all();
        return Inertia::render('dashboard/mostquestions',[
            'data'=>$mostquestions,
        ]);
    }


    public function orders(){
       /* $orders = orders::with(['product'=>function($query){
            $query->with('user','category');
        },'user'])->orderBy('id','DESC')->get();*/
        $orders = DB::table('orders')
            ->select('orders.*', 'products.ar_name as name',
                'categories.profit_percentage','centers.ar_name as center_name' ,
                'centers.delivery as delivery_cost',
                'clients.username','clients.phone',
                'orders_promo_code.promo_code_ar_name','old_price','new_price',
                'order_piece_data.color','order_piece_data.size','order_piece_data.info',
                DB::raw('vendors.username AS seller_name, vendors.phone AS seller_phone'))
            ->from('orders')
            ->join('products','orders.product_id','=','products.id')
            ->join('categories','categories.id','=','products.category_id')
            ->join('centers','orders.center_id','=','centers.id')
            ->join('order_piece_data','order_piece_data.order_id','=','orders.id')
            ->leftJoin('orders_promo_code','orders_promo_code.order_id','=','orders.id')
            ->join(DB::raw('users AS clients'),'orders.user_id','=','clients.id')
            ->join(DB::raw('users AS vendors'),'products.user_id','=','vendors.id')
            ->orderBy('orders.id','DESC')
            ->get();
        return Inertia::render('dashboard/orders',[
            'data'=>$orders,
            'governates'=>governates::selection()->get(),
        ]);
    }


    public function sellerspackages(){
        if(auth()->user()->type == 'admin') {
            $sellers_packs = sellers_packages::with(['package'=>function($e){
                $e->select('id',
                    app()->getLocale().'_name as name',app()->getLocale().'_info as info',
                    'no_products','no_orders');
            }, 'user'])->get();
            return Inertia::render('dashboard/sellerspackages', [
                'data' => $sellers_packs,
                'packages' => packages::selection()->get()
            ]);
        }else{
            return redirect('/');
        }
    }


    public function governates(){
        return Inertia::render('dashboard/governates',[
           'data'=>governates::all(),
        ]);
    }

    public function cities(governates $id){
        $cities = cities::where('governate_id','=',$id->id)->get();
        return Inertia::render('dashboard/cities',[
           'data'=>$cities,
            'governate_data'=>$id
        ]);
    }

    public function centers(cities $id){
        $centers = centers::where('city_id','=',$id->id)->get();
        return Inertia::render('dashboard/centers',[
            'data'=>$centers,
            'city_data'=>$id
        ]);
    }

    public function header(){

        return Inertia::render('dashboard/header_website',[
            'data'=>website_header::all(),
        ]);
    }


    public function deleteitem(){
        $id = request('id');
        $table = request('table');
        if($table == 'categories'){
            $sub = categories::where('parent_id','=',$id)->get();
            foreach($sub as $s){
                $s->delete();
            }
        }
        DB::table($table)->where('id','=',$id)->delete();
        echo 1;
    }

    public function search(){
        $columns = Schema::getColumnListing(request('table'));
        $output = DB::table(request('table'));
        $deleted = ['created_at','updated_at','email_verified_at'];

        foreach($deleted as $d){
            if(in_array($d,$columns)){
                $key = array_search($d,$columns);
                unset($columns[$key]);
            }
        }
        if(request('table') == 'products'){
            $output = products::selection()->with(['product_first_image','category'=>function($e){
                $e->select('id',app()->getLocale().'_name as name');
            },'user'])->where(function ($query) use ($columns) {
                foreach (['ar_name','en_name','ar_info','en_info','price'] as $column) {
                    $query->orWhere($column, 'LIKE', '%' . request('search') . '%');
                }
            });
            if(request('sub') > 0){
                $output->where('category_id','=',request('sub'));
            }
            if(request('seller_id') > 0 ){
                $output->where('user_id','=',request('seller_id'));
            }
            if(request('approval_status') != null){
                $output->where('approval','=',request('approval_status'));
            }


        }
        else if(request('table') == 'contactings'){
            $output = contactings::with('user')->where(function ($query) use ($columns) {
                foreach ($columns as $column) {
                    $query->orWhere($column, 'LIKE', '%' . request('search') . '%');
                }
            });
        }
        else if(request('table') == 'orders'){
         /*   $output = orders::with(['product'=>function($query){
                $query->with('category');
            },'product.user'=>function($query){
                $query->orWhere('username', 'LIKE', '%' . request('search') . '%');
            },'user'=>function($query){
                foreach (['phone','username'] as $column) {
                    $query->orWhere($column, 'LIKE', '%' . request('search') . '%');
                }
            }])->orderBy('id','DESC');


            $output = DB::table('orders')
                ->join('products','orders.product_id','=','products.id')
                ->join('users','orders.user_id','=','users.id')
                ->join('categories','products.category_id','=','categories.id')
                ->select('orders.*','users.*')
                ->orWhere('users.username','LIKE','%'.request('search').'%')
                ->orWhere('users.phone','LIKE','%'.request('search').'%')
                ->orWhere('products.name','LIKE','%'.request('search').'%')
                ->orderBy('orders.id','DESC');
*/
//            SELECT `orders`.* , `products`.*, `clients`.* , `vendors`.`username` as 'seller_name' , `vendors`.`phone` as 'seller_phone' FROM orders
//JOIN products ON orders.product_id = products.id
//JOIN users AS clients ON orders.user_id = clients.id
//JOIN users AS vendors ON products.user_id = vendors.id
//WHERE clients.username LIKE '%نه%'
//            OR vendors.username LIKE '%نه%'

            $output = DB::table('orders')
                ->select('orders.*', 'products.ar_name as name',
                    'categories.profit_percentage','centers.ar_name as center_name' ,
                    'centers.delivery as delivery_cost',
                    'clients.username','clients.phone',
                    'orders_promo_code.promo_code_ar_name','old_price','new_price',
                    'order_piece_data.color','order_piece_data.size','order_piece_data.info',
                    DB::raw('vendors.username AS seller_name, vendors.phone AS seller_phone'))
                ->from('orders')
                ->join('products','orders.product_id','=','products.id')
                ->join('categories','categories.id','=','products.category_id')
                ->join('centers','orders.center_id','=','centers.id')
                ->join('order_piece_data','order_piece_data.order_id','=','orders.id')
                ->join('orders_promo_code','orders_promo_code.order_id','=','orders.id')
                ->join(DB::raw('users AS clients'),'orders.user_id','=','clients.id')
                ->join(DB::raw('users AS vendors'),'products.user_id','=','vendors.id')
                ->where('clients.username','LIKE','%'.request('search').'%')
                ->orWhere('clients.phone','LIKE','%'.request('search').'%')
                ->orWhere('vendors.username','LIKE','%'.request('search').'%')
                ->orWhere('vendors.phone','LIKE','%'.request('search').'%')
                ->orWhere('products.ar_name','LIKE','%'.request('search').'%')
                ->orWhere('products.en_name','LIKE','%'.request('search').'%');


        }
        else if(request('table') == 'sellers_packages'){
            $output = sellers_packages::with(['package','user'])->orderBy('id','DESC')
                ->whereHas('user',function ($query) {
                    $query->where('username', 'LIKE', '%' . request('search') . '%');
                    $query->orWhere('phone', 'LIKE', '%' . request('search') . '%');
            });
        }
        else{

            if (request('table') == 'categories') {
                $output->where('parent_id', '=', request('parent_id'));
            }  else if (request('table') == "categories_questions") {
                $parent_id = categories::where('id','=',request('categories')[0])->first()->parent_id;
                $cats = request('categories');
                array_push($cats,$parent_id);
                $output = categories_questions::query()->with('category');
                $output->whereIn('category_id',$cats);
            }
            if(request('table') == 'users'){
                $output = User::query()->where('type','=',request('type'))
                    ->with('seller_package');
            }
            $output->where(function ($query) use ($columns) {
                foreach ($columns as $column) {
                    $query->orWhere($column, 'LIKE', '%' . request('search') . '%');
                }
            });
        }
        if(request('table') == 'products'){
            echo json_encode($output->orderBy('id','DESC')->paginate(9));
        }else {
            echo json_encode($output->get());
        }
    }

    public function updateblock(){
        $user = User::where('id','=',request('id'))->first();
        if(request('status') == 'true'){
            $status = 1;
        }else{
            $status = 0;
        }
        $user->block = $status;
        $user->save();
        echo 1;
    }




    public function saveitem(){
        $table = request('table');
        if(request()->has('id')){
            // update
            if($table == "categories"){
                $cat = categories::where('id','=',request('id'))->first();
                $cat->ar_name = request('ar_name');
                $cat->en_name = request('en_name');
                $cat->en_info = request('en_info');
                $cat->ar_info = request('ar_info');
                $cat->cat_order = request()->has('order') ? request('order') : 0;
                $cat->status = request('status');
                $cat->profit_percentage = request('profit_percentage');
                // if there is image uploaded
                if(request()->hasFile('image')){
                    $file = request()->file('image');
                    $extension = $file->extension();
                    $image = 'image.'. date('y-m-d'). time().'.'.$extension;
                    $file->move(public_path('images/categories/'), $image);
                    $cat->image = $image;
                }
                // if there is cover uploaded
                if(request()->hasFile('cover')){
                    $file = request()->file('cover');
                    $extension = $file->extension();
                    $image = 'image.'. date('y-m-d'). time().'.'.$extension;
                    $file->move(public_path('images/covers/'), $image);
                    $cat->cover = $image;
                }
                $cat->save();
                // update sub categories
                $sub_cats = categories::where('parent_id','=',request('id'));
                if($sub_cats->get()) {
                    $sub_cats->update([
                        'profit_percentage' => request('profit_percentage')
                    ]);
                }
                $output = categories::where('parent_id','=',$cat->parent_id)->orderBy('id','DESC')->get();
            }else if(request('table') == 'site_infos'){
                $site_info = SiteInfo::query()->where('name','=',request('name'))->first();
                $site_info->ar_content = request('ar_content');
                $site_info->en_content = request('en_content');
                $site_info->save();
                $output = $site_info;
            }
            else if(request('table') == 'features'){
                $feat = features::where('id','=',request('id'))->first();
                $feat->name = request('name');
                $feat->content = request('content');
                // if there is image uploaded
                if(request()->hasFile('image')){
                    $file = request()->file('image');
                    $extension = $file->extension();
                    $image = 'image.'. date('y-m-d'). time().'.'.$extension;
                    $file->move(public_path('images/features/'), $image);
                    $feat->image = $image;
                }
                $feat->save();
                $output = features::orderBy('id','DESC')->get();
            } else if(request('table') == 'website_header'){
                $cat = website_header::where('id','=',request('id'))->first();
                $cat->ar_content = request('ar_content');
                $cat->en_content = request('en_content');
                $cat->url = request('url');
                $cat->type = request('type');
                // if there is image uploaded
                if(request()->hasFile('image')){
                    $file = request()->file('image');
                    $extension = $file->extension();
                    $image = 'image.'. date('y-m-d'). time().'.'.$extension;
                    $file->move(public_path('images/home/'), $image);
                    $cat->image = $image;
                }
                $cat->save();
                $output = website_header::all();
            }
            else if(request('table') == 'users'){
                $data = request()->except('type','table');
                if(strlen(request('password')) > 0){
                    $data['password'] = bcrypt(request('password'));
                }else{
                    unset($data['password']);
                }
                User::query()->find(request('id'))->update($data);
                $output = User::query()->where('type','=',request('type'))
                    ->when(request('type') == 'seller',function($e){
                        $e->with('seller_package');
                    })->orderByDesc('id')->get();

            }
            else if(request('table') == 'categories_questions'){
                $question_data = categories_questions::where('id','=',request('id'))->with('category')->first();
                // if not change value of category id
                if( (request('category_id') != $question_data->category_id && request('type') == 'main') ||
                    (request('cat_id') != $question_data->category_id && request('type') == 'sub')
                ) {
                    // check if question has a parent category or sub category
                    if($question_data->category->parent_id == null){
                        // this is parent category
                        if(request('type') == 'sub'){
                            // add question to sub category
                            categories_questions::create([
                                'category_id'=>request('cat_id'),
                                'question'=>request('question')
                            ]);
                            $question_data->delete();
                        }
                    }else{
                        // this is sub category
                        if(request('type') == 'sub'){
                            // add question to sub category
                            categories_questions::create([
                                'category_id'=>request('cat_id'),
                                'question'=>request('question')
                            ]);
                        }
                        else if(request('type') == 'main'){
                            categories_questions::create([
                                'category_id'=>request('category_id'),
                                'question'=>request('question')
                            ]);
                        }
                        $question_data->delete();
                    }

                }else{
                    $question_data->question = request('question');
                    $question_data->save();
                }

                $sub_cats_info =  categories::where('id', '=', request('category_id'))
                    ->with('branches')->first()->branches;
                $sub_cats_ids = [];
                foreach($sub_cats_info as $cat){
                    array_push($sub_cats_ids,$cat->id);
                }
                $category = categories::where('id', '=', request('category_id'))->where('parent_id', '=', null)->first();
                $questions = categories_questions::where('category_id', '=', $category->id)->orderBy('id', 'DESC')->get();
                $sub_questions = categories_questions::whereIn('category_id',$sub_cats_ids)->with('category')->get();
                $output = ['questions'=>$questions,'sub_cats_sub_questions'=>$sub_questions];
            }
            else{
                $data = request()->except('table');

                DB::table($table)->where('id','=',request('id'))->update($data);
                if(request()->has('category_id')){
                    $output = DB::table($table)->where('category_id','=',request('category_id'))->get();
                }else if(request('table') == 'orders'){

                    $output  = DB::table('orders')
                        ->select('orders.*', 'products.ar_name as name',
                            'categories.profit_percentage','centers.ar_name as center_name' ,
                            'centers.delivery as delivery_cost',
                            'clients.username','clients.phone',
                            'orders_promo_code.promo_code_ar_name','old_price','new_price',
                            'order_piece_data.color','order_piece_data.size','order_piece_data.info',
                            DB::raw('vendors.username AS seller_name, vendors.phone AS seller_phone'))
                        ->from('orders')
                        ->join('products','orders.product_id','=','products.id')
                        ->join('categories','categories.id','=','products.category_id')
                        ->join('centers','orders.center_id','=','centers.id')
                        ->join('order_piece_data','order_piece_data.order_id','=','orders.id')
                        ->leftJoin('orders_promo_code','orders_promo_code.order_id','=','orders.id')
                        ->join(DB::raw('users AS clients'),'orders.user_id','=','clients.id')
                        ->join(DB::raw('users AS vendors'),'products.user_id','=','vendors.id')
                        ->orderBy('orders.id','DESC')
                        ->get();
                }else if(request('table') == 'cities'){
                    $output = DB::table($table)->where('governate_id','=',request('governate_id'))->get();
                }else if(request('table') == 'centers'){
                    $output = DB::table($table)->where('city_id','=',request('city_id'))->get();
                }else{

                    $output = DB::table($table)->get();
                }

            }

        }else{
            // create
            //categories table
            if($table == "categories"){
                // if there is image uploaded
                if(request()->hasFile('image')){
                    $file = request()->file('image');
                    $extension = $file->extension();
                    $image = 'image.'. date('y-m-d'). time().'.'.$extension;
                    $file->move(public_path('images/categories/'), $image);
                }else{
                    $image = 'default.png';
                }
                if(request()->hasFile('cover')){
                    $file = request()->file('cover');
                    $extension = $file->extension();
                    $cover = 'image.'. date('y-m-d'). time().'.'.$extension;
                    $file->move(public_path('images/covers/'), $cover);
                }else{
                    $cover = 'default.png';
                }
                if(request()->has('parent_id')){
                    $parent_id = request('parent_id');
                }else{
                    $parent_id = null;
                }
                $cat = categories::create([
                    'ar_name'=>request('ar_name'),
                    'en_name'=>request('en_name'),
                    'ar_info'=>request('ar_info'),
                    'en_info'=>request('en_info'),
                    'profit_percentage'=>request('profit_percentage'),
                    'image'=>$image,
                    'cover'=>$cover,
                    'cat_order'=>request()->has('order') ? request('order') : 0,
                    'status'=>request('status'),
                    'parent_id'=>$parent_id
                ]);
                $output = categories::where('parent_id','=',$parent_id)->orderBy('id','DESC')->get();
            }else if($table == "features"){
                // if there is image uploaded
                if(request()->hasFile('image')){
                    $file = request()->file('image');
                    $extension = $file->extension();
                    $image = 'image.'. date('y-m-d'). time().'.'.$extension;
                    $file->move(public_path('images/features/'), $image);
                }else{
                    $image = 'default.png';
                }

                $feat = features::create([
                    'name'=>request('name'),
                    'content'=>request('content'),
                    'image'=>$image,
                ]);
                $output = features::orderBy('id','DESC')->get();
            }else if($table == "website_header"){
                // if there is image uploaded
                if(request()->hasFile('image')){
                    $file = request()->file('image');
                    $extension = $file->extension();
                    $image = 'image.'. date('y-m-d'). time().'.'.$extension;
                    $file->move(public_path('images/home/'), $image);
                }else{
                    $image = 'default.png';
                }
                $cat = new website_header();
                $cat->ar_content = request('ar_content');
                $cat->en_content = request('en_content');
                $cat->url = request('url');
                $cat->type = request('type');
                $cat->image = $image;
                $cat->save();
                $output = website_header::all();
            }
            else if($table == "products"){
                $data = request()->except(['table','image']);
                $data['user_id'] = auth()->user()->id;
                $data['approval'] = 1;
                $pro_id = DB::table($table)->insertGetId($data);
                $file = request()->file('image');
                $extension = $file->extension();
                $image = 'image.'. date('y-m-d'). time().'.'.$extension;
                products_images::create([
                    'product_id'=>$pro_id,
                    'image'=>$image
                ]);
                $file->move(public_path('images/categories/'), $image);
                $output =  products::with(['product_first_image','category'])->get();
            }else if($table == "users"){
                $data = request()->except('table');
                $data['password'] = Hash::make(request('password'));
                DB::table($table)->insert($data);
                $output = DB::table($table)->whereIn('type',['employee','writer'])->get();
            }
            else if($table == "categories_questions"){

                categories_questions::create([
                    'category_id'=>request('category_id'),
                    'ar_question'=>request('ar_question'),
                    'en_question'=>request('en_question'),
                ]);

                $questions = categories_questions::where('category_id', '=', request('category_id'))->orderBy('id', 'DESC')->get();
                $output = ['questions'=>$questions];


            }
            else{
                $data = request()->except('table');
                $data['created_at'] = date('Y:m:d H:i:s');
                DB::table($table)->insert($data);
                if(request()->has('category_id')){
                    $output = DB::table($table)->where('category_id','=',request('category_id'))->get();
                }else if(request('table') == 'cities'){
                    $output = DB::table($table)->where('governate_id','=',request('governate_id'))->get();
                }else if(request('table') == 'centers'){
                    $output = DB::table($table)->where('city_id','=',request('city_id'))->get();
                }else{
                    $output = DB::table($table)->get();
                }

            }

        }
        echo json_encode(['output'=>$output]);
    }

    public function updateproduct(){
        if(request('input_name') == "approval"){
            if(request('value') == 'true'){
                $value = 1;
            }else{
                $value = 0;
            }
        }else{
            $value = request('value');
        }
        products::where('id','=',request('product_id'))->update([
            request('input_name')=>$value
        ]);
        echo $value;
    }

    public function updatepackadminstatus(){
        if(request('input_name') == "admin_control"){
            if(request('value') == 'true'){
                $value = 1;
            }else{
                $value = 0;
            }
        }else{
            $value = request('value');
        }
        sellers_packages::where('id','=',request('pack_id'))->update([
            request('input_name')=>$value
        ]);
        echo json_encode(sellers_packages::with(['package','user'])->get());
    }


    public function filterorders(){
        $output = DB::table('orders')
            ->select('orders.*', 'products.ar_name as name',
                'categories.profit_percentage','centers.ar_name as center_name' ,
                'centers.delivery as delivery_cost',
                'clients.username','clients.phone',
                'orders_promo_code.promo_code_ar_name','old_price','new_price',
                'order_piece_data.color','order_piece_data.size','order_piece_data.info',
                DB::raw('vendors.username AS seller_name, vendors.phone AS seller_phone'))
            ->from('orders')
            ->join('products','orders.product_id','=','products.id')
            ->join('categories','categories.id','=','products.category_id')
            ->join('centers','orders.center_id','=','centers.id')
            ->join('order_piece_data','order_piece_data.order_id','=','orders.id')
            ->leftJoin('orders_promo_code','orders_promo_code.order_id','=','orders.id')
            ->join(DB::raw('users AS clients'),'orders.user_id','=','clients.id')
            ->join(DB::raw('users AS vendors'),'products.user_id','=','vendors.id');

        if(request()->filled('name')){
            $output
                ->where(function ($query){
                    $query->orWhere('clients.phone','LIKE','%'.request('name').'%')
                        ->orWhere('orders.client_name','LIKE','%'.request('name').'%')
                        ->orWhere('vendors.username','LIKE','%'.request('name').'%')
                        ->orWhere('vendors.phone','LIKE','%'.request('name').'%')
                        ->orWhere('products.ar_name','LIKE','%'.request('name').'%')
                        ->orWhere('products.en_name','LIKE','%'.request('name').'%')
                        ->orWhere('clients.username','LIKE','%'.request('name').'%');
                });
        }

        if(request()->filled('from')){
            $output
                ->where('orders.created_at','>',date('Y:m:d H:i:s',strtotime(request('from'))));
        }
        if(request()->filled('to')){
            $output
                ->where('orders.created_at','<',date('Y:m:d H:i:s',strtotime(request('to'))));
        }
        if(request()->filled('governate_id')){
            $cities = cities::where('governate_id','=',request('governate_id'))->select('id')->get();
            // if user sent city id
            if(request()->filled('city_id')){
                $cities = cities::where('governate_id','=',request('governate_id'))
                                ->where('id','=',request('city_id'))->select('id')->get();
            }


            $check_centers_ids = [];
            for($i = 0; $i<sizeof($cities); $i++){
                // get all centers inside specific city
                $centers = centers::where('city_id','=',$cities[$i]['id'])->get();
                // check if user sent center id
                if(request()->filled('center_id')){
                    $centers = centers::where('city_id','=',$cities[$i]['id'])->where('id','=',request('center_id'))->get();
                }
                if($centers != null){
                    for($j = 0; $j < sizeof($centers); $j++){
                        array_push($check_centers_ids,$centers[$j]['id']);
                    }
                }

            }
            // check i have centers which found in orders table in database
                $output
                    ->whereIn('orders.center_id',$check_centers_ids);


        }





        return response()->json($output->get());
    }


    public function deletespecific(){
        if(sizeof(request('ids')) > 0){
            foreach (request('ids') as $id){
                DB::table(request('table'))->where('id','=',$id)->delete();
            }
        }
        echo json_encode(1);
    }

    public function adminstatics(){
        $un_seen_messages =  collect(contactings::my_unseen_data_dashboard())->sum(function($e){
            return $e->sum_inbox;
        });
        $not_approved_products = products::query()->where('approval','=','0')->count();
        return response()->json(['un_seen_messages'=>$un_seen_messages,'not_approved'=>$not_approved_products]);
    }


}