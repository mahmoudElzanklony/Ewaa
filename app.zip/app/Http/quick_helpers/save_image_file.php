<?php


namespace App\Http\quick_helpers;


class save_image_file
{
    public static function save_image($image , $path){
        $rand = mt_rand(100000, 999999);
        if(in_array($image->getClientOriginalExtension(),['png','jpg','jpeg','gif'])) {
            $name = time() . "_" . $rand . "." . $image->getClientOriginalExtension();
            $image->move(public_path('images/'.$path), $name);

            return $name;
        }else{
            return messages_output::error_message(trans('errors.image_error'));
        }
    }


}
