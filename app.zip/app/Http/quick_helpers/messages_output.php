<?php


namespace App\Http\quick_helpers;


class messages_output
{
    public static function success_message($message){
        return response()->json(['success'=>$message]);
    }


    public static function error_message($message){
        return response()->json(['errors'=>$message]);
    }

}
