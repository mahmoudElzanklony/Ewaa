<?php


namespace App\Http\services;


use App\Http\Controllers\classes\sms\SMS_misr;
use App\Http\Controllers\classes\users\save_seller_package_info;
use App\Http\quick_helpers\messages_output;
use App\Http\Requests\UsersValidation;
use App\Models\marketer_info;
use App\Models\packages;
use App\Models\User;
use App\Models\users_points;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class Auth_Users
{
    public static function register($val , $request){
        // check if value of type is admin or seller or buyer
        $validated = $val->validated();
        $validated['password'] = bcrypt($val->password);
        $validated['serial_number'] = time();
        if($request->type == 'seller'){
            $validated['block'] = 1;
        }

        if($request->type == 'seller'){

            // check image extension
            $image_validation = Validator::make($request->all(),[
                'store_image'=>'file|image|mimes:png,jpeg,gif'
            ]);
            if($image_validation->fails()){
                return messages_output::error_message(['store_image'=>trans('errors.image_error')]);
            }else{
                $user = User::create($validated);


                $request->query->set('user_id',$user->id);
                $request->query->set('package_id',packages::where('no_orders','=',0)->first()->id);
                $request->query->set('admin_control',0);

                save_seller_package_info::save_seller_package_data($request);
            }

            // pass data to seller package info request

        }else{
            $user = User::create($validated);
            if($request->type == 'marketer'){
                marketer_info::query()->create([
                    'user_id'=>$user->id,
                    'page_link'=>$request->market_page
                ]);
            }else{
                users_points::query()->create([
                    'user_id'=>$user->id,
                    'points'=>0,
                ]);
            }
        }
        $verify = 'رمز دخولك الي حسابك في موقع بنكسي في حاله نسيانك كلمه المرور هو '.$validated['serial_number'];
        SMS_misr::send(['sms'=>$verify,'phone'=>$user->phone]);

        auth()->login($user);
        return messages_output::success_message($user);

    }

    public static function login(UsersValidation $res){
        if(auth()->attempt(['phone'=>$res->phone , 'password'=>$res->password ] ) ){
            $status = 1;
            $result = auth()->user();
            return  messages_output::success_message(['status'=>$status,'result'=>$result]);

        }else{
            $status = 0;
            $result = trans('errors.unauthenticated');
            return  messages_output::error_message(['status'=>$status,'result'=>$result]);

        }
    }
}
